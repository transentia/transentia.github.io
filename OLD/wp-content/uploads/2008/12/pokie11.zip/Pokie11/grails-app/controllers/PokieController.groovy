class PokieController {
  def evaluatorService

  def index = {session.spindle = new pokie.Spindle(); session.spindle.reset(); redirect(action: show) }

  def show = { session.evaluatorResult = evaluatorService.evaluate(session.spindle) }

  def play = {session.spindle.activate(); redirect(action: show) }
}
