package pokie

class Evaluation {
  int leftReelValue
  int middleReelValue
  int rightReelValue
  boolean initialised
  EvaluatorResult result
}
