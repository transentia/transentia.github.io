package pokie

public enum EvaluatorResult {
  INACTIVE, LOSE, BIGWIN, MEDIUMWIN_ASC, MEDIUMWIN_DSC, SMALLWIN, BROKEN, OTHER
}