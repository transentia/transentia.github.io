package pokie;

public class Reel {
  final rand = new Random()

  int value

  private rint = { rand.nextInt(5) + 1  }

  def reset = { value = 3 }

  def activate = { value = rint() }
}
