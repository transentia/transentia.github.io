package pokie;

public class Spindle {
  private final spindle = [leftReel: new Reel(), middleReel: new Reel(), rightReel: new Reel()]

  private initialised = false;

  def reset = { initialised = false; spindle.each { k, v ->  v.reset() } }

  def activate = { initialised = true; spindle.each { k, v -> v.activate() } }

  def getSpindle = { Collections.unmodifiableList(spindle) }
}
