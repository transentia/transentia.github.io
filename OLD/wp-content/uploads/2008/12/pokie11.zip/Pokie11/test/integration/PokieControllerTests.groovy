class PokieControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
