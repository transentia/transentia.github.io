UNIX System Administration
==========================

* History
Between 1999 and 2002 I ran a course on �Unix System Administration.� It was presented in the US (New York), around Australia and Macau. 

The course was pitched at people who were intending to step into a Linux System Administration role and who (may) already have known a little bit about Linux.

It was promoted as a five-day course, to give plenty of hands-on time. There are quite a few exercises and we always started with a �bare� machine and a RedHat Linux CD-ROM, so participants tended to need a fair bit of �play� time; it wasn�t all talking head. One or twice I did it in 3 days; it was pretty rushed, but the customer gets what the customer wants!

Because it is not really my �core business� (which is: enterprise Java development) I didn�t really give the material the care and feeding it needed and eventually stopped promoting and maintaining it.

It is now at End of Life. I figure that it would be such a pity for it to end as a set of bits decaying away on my hard disk so I am opening it up to the world.

Enjoy!

Bob Brown
linuxcourseware@transentia.com.au
http://www.transentia.com.au

* DonationWare
If you like it, send me an email!

If you find this material useful, please consider paying me a small amount (AUD$10, say). 

My paypal account is:  https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=6348333

* Legalese
This content is provided "as-is", with no guaranteees.

Feel free to use it, but not to abuse it (to give a couple of examples: don't make hundreds of copies for friends; don't claim it as your own work).

I retain copyright, so "all rights reserved."

