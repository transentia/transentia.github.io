Developing with JavaScript Technologies
=======================================

* History
This course was created in mid-2002.

It was created for ASERT (http://www.asert.com.au) but never actually saw the light of day. This was after the dot-com bubble had burst and the ultimately commissioning organisation probably went bust or lost interest or something...I can't remember now! 

The course was pitched at people who wanted a very quick overview of what was then a 'warm', upcoming topic. I tried to show JavaScript in a good light, not just as an adjunct to a browser. This was before Jesse James Garrett thought of the term AJAX (reputedly while in the shower)!

There was plenty of hands-on time. There are quite a few small and simple exercises.

It is now at End of Life. I figure that it would be such a pity for it to end as a set of bits decaying away on my hard disk so I am opening it up to the world.

Enjoy!

Bob Brown
javascriptcourseware@transentia.com.au
http://www.transentia.com.au

* DonationWare
If you like it, send me an email!

If you find this material useful, please consider paying me a small amount (AUD$10, say). 

My paypal account is:  https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=6550782

* Legalese
This content is provided "as-is", with no guaranteees.

Feel free to use it, but not to abuse it (to give a couple of examples: don't make hundreds of copies for friends; don't claim it as your own work).

I retain copyright, so "all rights reserved."

