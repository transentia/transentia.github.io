XML Overview for Developers
===========================

* History
This course was presented all around Australia and Macau between about 2000 and 2002.

It was often run under the ASERT banner (http://www.asert.com.au) and sometimes under the Software Engineering Australia (SEA, now defunct) banner. 

The course was pitched at people who wanted a very quick (2-3 day) overview of what was then a 'hot', upcoming topic.

A cut-down one-day version was also offered as a public 'informational' course a few times.

There was plenty of hands-on time. There are quite a few small and simple exercises.

Eventually, the XML world exploded to such an extent that I couldn't keep tracking the changes (think about the changes the XML Schema language went through, for instance) and there was so much other material around that it was no longer cost-effective for me to give the material the care and feeding it needed and I eventually stopped promoting and maintaining it.

It is now at End of Life. I figure that it would be such a pity for it to end as a set of bits decaying away on my hard disk so I am opening it up to the world.

Enjoy!

Bob Brown
xmlcourseware@transentia.com.au
http://www.transentia.com.au

* DonationWare
If you like it, send me an email!

If you find this material useful, please consider paying me a small amount (AUD$10, say). 

My paypal account is:  https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=6545233

* Legalese
This content is provided "as-is", with no guaranteees.

Feel free to use it, but not to abuse it (to give a couple of examples: don't make hundreds of copies for friends; don't claim it as your own work).

I retain copyright, so "all rights reserved."

