ava Technology and Development
==============================

* History
This course was started in ~1996 as Java was becoming popular. I stopped
hacking it sometime around 2002, so it had a pretty good run. This
version is from sometime in 2001 (it was pretty much the first "reasonably
up-to-date" copy I found in my archive...actually a big pile of CDs).

This course had a lot of mileage: it went around Australia and the US many
times, it went around various bits of Asia a couple of times and it went
to NZ a few times.  It was used by a team of presenters, each of whom
presented it very differrently, interestingly enough, and contributed
bits and pieces and bugfixes to it (thanks, guys!). Nonetheless, it
retained my somewhat cynical/quirky view of the Java Universe.

It was presented under a few different banners. Never under the transentia
banner in Australia.  It was even �informally� licensed (meaning I pretty
much got ripped-off!) to a US company for their purposes (whatever they
were--I never really found out).

I have also presented Java courseware for a number of other organisations
and I still believe that this is the best.

When the course first burst onto the world, the course participants were
all keen and clever "early adopters": for exercises, it was enough to
say "here is a Java compiler, go build me an �X�" and everyone had fun,
and learned lots along the way. By the time I knocked it on its head--no
more early adopters were coming through and in some cases we had to deal
with people who simply didn�t want to know but were being told to follow
the company line--the exercises were having to be specified a lot more
completely (it seemed like we had to detail practically every keypress
and mouse movement). It wasn�t so much fun at the end, sad to say!

I remember presenting it for the very first time, to a local ISP in
Darwin. After discussing Applets, I was talking about how Applets
could be used to build a Tsunami-style D.O.S. attack and bring down a
whole network. Suddenly one participant jumped up and walked out and
I didn�t see him for quite a whle. Turns out that he was the owner
of the company. He later explained that he had just spent a day madly
reconfiguring his servers and network to be more resistant to the type
of attack I had been talking about. I really scared the poor guy!

It is now at End of Life. I figure that it would be such a pity for it
to end as a set of bits decaying away on my hard disk so I am opening
it up to the world.

Enjoy!

Bob Brown
javacoursewaredonationware@transentia.com.au
http://www.transentia.com.au

* DonationWare
If you like it, send me an email!

If you find this material useful, please consider paying me a small amount (AUD$10, say). 

My paypal account is: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=6584697

* Legalese
This content is provided "as-is", with no guaranteees.

Feel free to use it, but not to abuse it (to give a couple of examples: don't make hundreds of copies for friends; don't claim it as your own work).

I retain copyright, so "all rights reserved."

