SOAP/WebServices
================

* History
This course was created in mid-2003.

It was a quick, one-day overview/review of the current "state of the art."

How things change!

It is now at End of Life. I figure that it would be such a pity for it to end as a set of bits decaying away on my hard disk so I am opening it up to the world.

Enjoy!

Bob Brown
soapwscourseware@transentia.com.au
http://www.transentia.com.au

* DonationWare
If you like it, send me an email!

If you find this material useful, please consider paying me a small gratuity (AUD$5, say). 

My paypal account is: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=6565587

* Legalese
This content is provided "as-is", with no guaranteees.

Feel free to use it, but not to abuse it (to give a couple of examples: don't make hundreds of copies for friends; don't claim it as your own work).

I retain copyright, so "all rights reserved."

