To save space, the exemplar application is shipped without any necessary jars.

You will need to supply the following:

ShippingCostWS\lib
  groovyws-standalone-0.5-SNAPSHOT.jar

SI\lib
  activemq-all-5.2.0.jar
  activemq-pool-5.2.0.jar
  com.springsource.org.aopalliance-1.0.0.jar
  com.springsource.org.apache.commons.codec-1.3.0.jar
  com.springsource.org.apache.commons.collections-3.2.0.jar
  com.springsource.org.apache.commons.httpclient-3.1.0.jar
  com.springsource.org.apache.commons.lang-2.1.0.jar
  com.springsource.org.apache.commons.logging-1.1.1.jar
  com.springsource.org.apache.ws.commons.schema-1.3.2.jar
  org.springframework.aop-2.5.6.A.jar
  org.springframework.beans-2.5.6.A.jar
  org.springframework.context-2.5.6.A.jar
  org.springframework.context.support-2.5.6.A.jar
  org.springframework.core-2.5.6.A.jar
  org.springframework.integration-1.0.2.RELEASE.jar
  org.springframework.integration.adapter-1.0.2.RELEASE.jar
  org.springframework.integration.event-1.0.2.RELEASE.jar
  org.springframework.integration.file-1.0.2.RELEASE.jar
  org.springframework.integration.http-1.0.2.RELEASE.jar
  org.springframework.integration.httpinvoker-1.0.2.RELEASE.jar
  org.springframework.integration.jms-1.0.2.RELEASE.jar
  org.springframework.integration.mail-1.0.2.RELEASE.jar
  org.springframework.integration.rmi-1.0.2.RELEASE.jar
  org.springframework.integration.samples-1.0.2.RELEASE.jar
  org.springframework.integration.security-1.0.2.RELEASE.jar
  org.springframework.integration.stream-1.0.2.RELEASE.jar
  org.springframework.integration.ws-1.0.2.RELEASE.jar
  org.springframework.integration.xml-1.0.2.RELEASE.jar
  org.springframework.jms-2.5.6.A.jar
  org.springframework.oxm-1.5.5.A.jar
  org.springframework.security-2.0.4.A.jar
  org.springframework.transaction-2.5.6.A.jar
  org.springframework.web-2.5.6.A.jar
  org.springframework.web.servlet-2.5.6.A.jar
  org.springframework.ws-1.5.5.A.jar
  org.springframework.xml-1.5.5.A.jar
