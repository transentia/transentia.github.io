11:22 AM 14/04/2009

The exemplar application was developed on Vista. It has not been tested under Linux or any other OS. 

It was developed using:
Grails 1.1 (http://www.grails.org)
Groovy 1.6.1 (http://groovy.codehaus.org)
Apache ActiveMQ 5.2.0 (http://activemq.apache.org)
GroovyWS 0.5 snapshot (http://snapshots.dist.codehaus.org/groovy/distributions/groovyws/)
Gant 1.6.1 (http://gant.codehaus.org)

It is probably best to ensure that the application directory is in a path that does not contain spaces (eg: C:\DEVELOPMENT\SI).

The following environment variables are required to be set:
GANT_HOME
GROOVY_HOME
GRAILS_HOME
ACTIVEMQ_HOME

There exists a default gant build file at the top level directory (alongside this README); practically everything can be done via this:

C:\DEVELOPMENT\SI>gant -p

 0_runAMQ                                 Run ActiveMQ
 1_runAMQALPartition               Run the AMQ Server; A-L partition
 2_runAMQMZPartition              Run the AMQ Server; M-Z partition
 3_runShippingCostWebService  Run the Shipping Cost WebService
 4_runGrailsApp                           Run the Grails Application

It is necessary to run each gant in a separate Command Prompt window, in the order indicated by each task's prefix, ie:

C:\DEVELOPMENT\SI>gant 0_runAMQ

Then point your browser to http://localhost:9090/SI

NB:
On Vista, the various processes don't shutdown cleanly, even if their containing Command Prompt window is killed. SysInernal's "Process Explorer" [http://technet.microsoft.com/en-us/sysinternals/bb896653.aspx] can help you see which processes are hanging around, and can let you terminate them.