class DemoBeanService {

    boolean transactional = false

    def doSomething(String input) {
		  input.toUpperCase();
    }
}
