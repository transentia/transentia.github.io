package au.com.transentia.si;

public class CsvTransformer {
  def homeBase

  public String transform(String csv) {    
    def dest = csv.tokenize(',')[1]

    """<def:calculateShippingCost xmlns:def="http://DefaultNamespace">
         <def:arg0>$homeBase</def:arg0>
         <def:arg1>$dest</def:arg1>
         <def:arg2>1</def:arg2>
      </def:calculateShippingCost>"""
  }
}

