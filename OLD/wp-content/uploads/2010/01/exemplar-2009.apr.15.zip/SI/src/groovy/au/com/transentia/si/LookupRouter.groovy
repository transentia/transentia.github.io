package au.com.transentia.si

public class LookupRouter {

  public String route(String msg) {    
    switch(msg) {
      case ~/(?i:[a-l].*)/: return 'ALOutboundChannel'
      case ~/(?i:[m-z].*)/: return 'MZOutboundChannel'
      default: return 'RoutingRejectChannel'
    }
  }
}


