8:36 PM 2/05/2009

The example application was developed on Vista. It has not been tested under Linux or any other OS. 

Prerequisites:

Java 1.6

Groovy 1.6.2 (http://groovy.codehaus.org)Spring Framework 2.5.6 (http://www.springsource.com/download)
 Spring Batch 2.0.0.RELEASE (http://static.springsource.org/spring-batch/)
Gant 1.6.1 (http://gant.codehaus.org)
Spring Modules 0.9 - Valang (https://springmodules.dev.java.net/)
Spring OXM (http://static.springsource.org/spring-ws/sites/1.5/)
Apache commons logging 1.1.1 (http://commons.apache.org/logging/)
Apache commons collections 3.2.1 (http://commons.apache.org/collections/)

It is probably best to ensure that the application directory is in a path that does not contain spaces (eg: C:\DEVELOPMENT\SB).

The following environment variables are required to be set:
JAVA_HOME
GANT_HOME
GROOVY_HOME

The appropriate entries should also be added to the PATH variable.

There exists a default gant build file at the top level directory (alongside this README); you can run the application via this. 

*** You will need to alter the various paths in the build.gant file so that it can pick up the prerequisite jar files.

Also included is an Intellij project file.

*** You will need to alter the project so that it can pick up the prerequisite jar files.

As it stands, job.xml is configured such that the job takes input from resource\data\inputdata.dat and produces resource\data\errors.txt and resource\data\job-output.xml. These files are included in this zip.

