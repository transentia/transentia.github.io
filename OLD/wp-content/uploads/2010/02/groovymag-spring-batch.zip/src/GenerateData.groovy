import groovy.text.SimpleTemplateEngine

def template = '''BEGIN$beginSeq
CUST,9876543210
CONT,0416123456,0712340987,fred@nowhere.com
CARD,visa:1234 1234 4321 432$digit:000
BAL,1000.00
END$endSeq'''

def engine = new SimpleTemplateEngine()

def rnd = new Random()

out = new File("../../data/100000data.out")
out.withWriter {writer ->
  (1..100000).each {
    def bs = String.format("%010d", it)
    def es = rnd.nextGaussian() > 0.9 ? String.format("x%09d", it) : bs
    def digit = rnd.nextGaussian() > 0.95 ? 9 : 1
    def binding = ["beginSeq": bs, "endSeq": es, "digit": digit]

    def text = engine.createTemplate(template).make(binding)

    writer << text.toString() << "\n"
  }
}
