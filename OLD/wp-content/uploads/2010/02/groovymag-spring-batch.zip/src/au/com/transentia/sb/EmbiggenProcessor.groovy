package au.com.transentia.sb

import org.springframework.batch.item.ItemProcessor

public class EmbiggenProcessor
  implements ItemProcessor<MultilineRecord, MultilineRecord> {

  def percent

  public MultilineRecord process(MultilineRecord mlr) throws Exception {
    mlr.balance *= percent

    mlr
  }
}

