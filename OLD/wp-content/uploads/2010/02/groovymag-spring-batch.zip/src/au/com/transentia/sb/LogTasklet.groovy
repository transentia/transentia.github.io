package au.com.transentia.sb

import org.springframework.batch.core.StepContribution
import org.springframework.batch.core.scope.context.ChunkContext
import org.springframework.batch.core.step.tasklet.Tasklet
import org.springframework.batch.repeat.RepeatStatus
import org.apache.commons.logging.LogFactory

public class LogTasklet implements Tasklet {
  static log = LogFactory.getLog(LogTasklet);

  def message

  public RepeatStatus execute(StepContribution contribution,
                              ChunkContext chunkContext) throws Exception {
    log.info message

    RepeatStatus.FINISHED
  }
}
