package au.com.transentia.sb

import org.springmodules.validation.valang.functions.AbstractFunction
import org.springmodules.validation.valang.functions.Function

//---------------------------------------------------------
// Checks for valid credit card number using Luhn algorithm
//---------------------------------------------------------

// http://www.merriampark.com/anatomycc.htm

public class LuhnFunction extends AbstractFunction {

  public LuhnFunction(Function[] arg0, int arg1, int arg2) {
    super(arg0, arg1, arg2);
    definedExactNumberOfArguments(1);
  }

  @Override
  protected Object doGetResult(Object target) throws Exception {
    def str = getArguments()[0].getResult(target).toString()
    isValid(str)
  }

//-------------------
// Perform Luhn check
//-------------------

  public static boolean isValid(String cardNumber) {
    def sum = 0
    def addend = 0
    def timesTwo = false

    cardNumber.replaceAll(' ', '').each {dc ->
      def digit = Integer.valueOf(dc)
      if (timesTwo)
      {
        addend = digit * 2
        if (addend > 9)
          addend -= 9;
      }
      else
        addend = digit
      sum += addend
      timesTwo = !timesTwo
    }

    (sum % 10) == 0
  }

//-----
// Test
//-----

  public static void main(String[] args) {
    String cardNumber = "4408 0412 3456 7890";
    boolean valid = LuhnFunction.isValid(cardNumber);
    System.out.println(cardNumber + ": " + valid);
    cardNumber = "4408 0412 3456 7893";
    valid = LuhnFunction.isValid(cardNumber);
    System.out.println(cardNumber + ": " + valid);
    cardNumber = "4417 1234 5678 9112";
    valid = LuhnFunction.isValid(cardNumber);
    System.out.println(cardNumber + ": " + valid);
    cardNumber = "4417 1234 5678 9113";
    valid = LuhnFunction.isValid(cardNumber);
    System.out.println(cardNumber + ": " + valid);
  }

}
