package au.com.transentia.sb

public class MultilineRecord
{
  String sequence
  String endSequence

  Long id

  String mobile
  String landline
  String email

  String provider
  String number
  String security

  BigDecimal balance

  @Override
  public String toString()
  {
    final StringBuilder sb = new StringBuilder()
    sb.append("MultilineRecord(")
      .append(sequence).append('/').append(endSequence)
      .append(") {id=").append(id)
      .append(", mobile='").append(mobile).append('\'')
      .append(", landline='").append(landline).append('\'')
      .append(", email='").append(email).append('\'')
      .append(", provider='").append(provider).append('\'')
      .append(", number='").append(number).append('\'')
      .append(", security='").append(security).append('\'')
      .append(", balance='").append(balance).append('\'')
      .append('}')
    sb.toString();
  }

}
