package au.com.transentia.sb

import org.springframework.batch.item.ExecutionContext
import org.springframework.batch.item.ItemReader
import org.springframework.batch.item.ItemStream
import org.springframework.batch.item.ItemStreamException
import org.springframework.batch.item.file.FlatFileItemReader
import org.springframework.batch.item.file.transform.FieldSet
import org.springframework.util.Assert

public class MultilineRecordReader implements ItemReader<MultilineRecord>, ItemStream
{

  private FlatFileItemReader<FieldSet> flatFileItemReaderDelegate

//  BEGIN0000000000
//  CUST,9876543210
//  CONT,0416123456,0712340987,fred@nowhere.com
//  CARD,visa:1234123443214321:888
//  BAL,1000.00
//  END

  public MultilineRecord read() throws Exception
  {
    MultilineRecord mlr = null

    // flags to indicate the presence of component lines
    def customerSeen = false;
    def contactsSeen = false
    def ccSeen = false
    def balSeen = false

    def line
    while (line = this.flatFileItemReaderDelegate.read())
    {
      String prefix = line.readString(0);
      switch (prefix)
      {
        case 'BEGIN':
          mlr = new MultilineRecord(sequence: line.readString(1))
          break

        default:
          Assert.notNull(mlr, "MultilineRecord not yet intialised")
          switch (prefix)
          {
            case 'CUST':
              mlr.id = line.readLong(1)
              customerSeen = true
              break

            case 'CONT':
              mlr.with {
                mobile = line.readString(1)
                landline = line.readString(2)
                email = line.readString(3)
              }
              contactsSeen = true
              break

            case 'CARD':
              mlr.with {
                provider = line.readString(1)
                number = line.readString(2)
                security = line.readString(3)
              }
              ccSeen = true
              break;

            case 'BAL':
              mlr.balance = line.readBigDecimal(1)
              balSeen = true
              break

            case 'END':
              // check all record fields seen
              Assert.isTrue(mlr && customerSeen &&
                            contactsSeen && ccSeen && balSeen,
                  "Incomplete Record Found")
              mlr.endSequence = line.readString(1)
              return mlr
              break
          }
      }
    }
    null
  }

  public void setFlatFileItemReaderDelegate(FlatFileItemReader<FieldSet> flatFileItemReaderDelegate)
  {
    this.flatFileItemReaderDelegate = flatFileItemReaderDelegate;
  }

  public void close() throws ItemStreamException
  {
    this.flatFileItemReaderDelegate.close();
  }

  public void open(ExecutionContext executionContext) throws ItemStreamException
  {
    this.flatFileItemReaderDelegate.open(executionContext);
  }

  public void update(ExecutionContext executionContext) throws ItemStreamException
  {
    this.flatFileItemReaderDelegate.update(executionContext);
  }
}
