package au.com.transentia.sb

import org.springframework.batch.item.file.transform.LineAggregator

public class PassThroughLineAggregator implements LineAggregator<MultilineRecord> {
  public String aggregate(MultilineRecord item) {
    item.toString()
  }
}
