package au.com.transentia.sb

import org.springframework.batch.core.listener.SkipListenerSupport

public class SkipListener extends SkipListenerSupport<MultilineRecord, Object> {
  def writer

  @Override
  public void onSkipInProcess(MultilineRecord item, Throwable t) {
    writer.write ( [ item ] )
  }
}
