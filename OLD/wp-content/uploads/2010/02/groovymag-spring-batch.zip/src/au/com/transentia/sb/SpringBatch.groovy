package au.com.transentia.sb

import org.springframework.batch.core.JobParametersBuilder
import org.springframework.context.support.ClassPathXmlApplicationContext

public class SpringBatch {

  public static void main(String[] args) {
    def context =
      new ClassPathXmlApplicationContext(['applicationContext.xml',
                                          'job.xml'] as String[],
          true)

    def jobLauncher = context.getBean('jobLauncher')

    def job = context.getBean('job')

    def adjustmentPercent = 1.01D;

    def jobExecution =
      jobLauncher.run(job,
        new JobParametersBuilder().
          addDouble("adjustment.percent", adjustmentPercent).toJobParameters())
    jobExecution.with {
      println """
Job: $jobId
StartTime: $startTime; EndTime: $endTime
Duration: ${endTime.time - startTime.time} ms
Status=$exitStatus
"""
      stepExecutions.each { println "STEP: $it" }
    }
  }
}
