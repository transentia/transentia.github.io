application {
	title="Gr3Client"
	startupGroups=["Gr3Client"]
	autoShutdown=false
}
griffon.rest.injectInto=["service"]
mvcGroups {
	PrefsPanel {
		model="PrefsPanelModel"
		controller="PrefsPanelController"
		actions="PrefsPanelActions"
		view="PrefsPanelView"
	}
	Gr3Client {
		model="Gr3ClientModel"
		controller="Gr3ClientController"
		actions="Gr3ClientActions"
		menus="Gr3ClientMenus"
		view="Gr3ClientView"
	}
}
