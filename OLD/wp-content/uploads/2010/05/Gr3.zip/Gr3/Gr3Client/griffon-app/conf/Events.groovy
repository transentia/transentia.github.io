// configuration to assist logging REST plugin
//
/*import org.apache.log4j.Logger

onNewInstance = {klass, type, instance ->
  instance.metaClass.logger =
    instance.metaClass.log = Logger.getLogger("gr3Client.${klass.name}")
}*/
