import groovy.beans.Bindable

class Gr3ClientModel {
  @Bindable String totalizerValue = '$0'
  @Bindable String earnings = '$0'
  @Bindable String message = 'Good Luck!'
  @Bindable String playedValue = '$0'
  @Bindable Integer plays = 0
  @Bindable Boolean playButtonEnabled = true
}
