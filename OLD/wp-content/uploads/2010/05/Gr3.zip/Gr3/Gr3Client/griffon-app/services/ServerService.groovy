import static groovyx.net.http.ContentType.*

class ServerService {

  def registerAction = {->
    withRest(uri: NetworkUtils.URI) {
      def resp = post(path: 'register',
              responseContentType: TEXT)
      assert resp.status == 200
      assert resp.data.text == "OK"
    }
  }

  def unRegisterAction = {->
    withRest(uri: NetworkUtils.URI) {
      def resp = delete(path: 'unRegister',
              responseContentType: TEXT)
      assert resp.status == 200
      assert resp.data.text == "OK"
    }
  }

  def totalizerAction = {->
    withRest(id: 'totalizer', uri: NetworkUtils.URI) {
      def resp = get(path: 'totalizer',
              responseContentType: JSON)
      assert resp.status == 200
      resp.data.tote
    }
  }

  def playAction = {value ->
    withRest(id: 'play', uri: NetworkUtils.URI) {
      def resp = put(path: 'play',
              body: [amount: value],
              requestContentType: JSON,
              responseContentType: JSON)
      assert resp.status == 200
      resp.data.tote
    }
  }

  def winAction = {pv, w ->
    withRest(id: 'play', uri: NetworkUtils.URI) {
      def resp = put(path: 'win',
              body: [playValue: pv, winnings: w],
              requestContentType: JSON,
              responseContentType: JSON)
      assert resp.status == 200
      resp.data.tote
    }
  }
}
