class Evaluation {
  def leftReelValue
  def middleReelValue
  def rightReelValue
  def special
  EvaluatorResult result
}
