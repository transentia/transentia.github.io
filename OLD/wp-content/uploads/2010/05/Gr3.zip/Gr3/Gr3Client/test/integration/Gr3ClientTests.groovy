import griffon.util.IGriffonApplication

class Gr3ClientTests extends GroovyTestCase {

    IGriffonApplication app

    void testSomething() {

    }
}
