class ServerServiceServiceTests extends GroovyTestCase {

    void testSomething() {

    }
}
