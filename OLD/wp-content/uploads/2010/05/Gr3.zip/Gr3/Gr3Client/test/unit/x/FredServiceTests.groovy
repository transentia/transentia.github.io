package x

class FredServiceTests extends GroovyTestCase {

    void testSomething() {

    }
}
