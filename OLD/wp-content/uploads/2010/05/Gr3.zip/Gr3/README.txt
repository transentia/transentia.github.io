Gr3Server is a Grails 1.2.2 application.

To run, from the command-line:

  grails run-app

Gr3Server should be run BEFORE Gr3Client.

Gr3Client is a Griffon 0.3 application.

To run, from the command-line:

  griffon run-app

These were developed using Windows 7 and 64-bit Java 1.6.0_20.
