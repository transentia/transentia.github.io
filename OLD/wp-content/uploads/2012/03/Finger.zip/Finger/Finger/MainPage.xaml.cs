﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO.IsolatedStorage;
using System.Windows.Navigation;
using Microsoft.Phone.Shell;

namespace Finger
{
  public partial class MainPage : PhoneApplicationPage
  {
    private void About_Click(object sender, EventArgs e)
    {
      //MessageBox.Show("Prefs button works!");
      NavigationService.Navigate(new Uri("/AboutPivotPage.xaml", UriKind.Relative));

      //Do work for your application here.
    }

    private void Prefs_Click(object sender, EventArgs e)
    {
      //MessageBox.Show("Prefs button works!");
      NavigationService.Navigate(new Uri("/PrefsPage.xaml", UriKind.Relative));

      //Do work for your application here.
    }

    private void Add_Click(object sender, EventArgs e)
    {
      //MessageBox.Show("Add button works!");
      NavigationService.Navigate(new Uri("/Scribble.xaml?action=add", UriKind.Relative));

      //Do work for your application here.
    }

    private void Edit_Click(object sender, EventArgs e)
    {
      //MessageBox.Show("Edit button works!");
      NavigationService.Navigate(new Uri("/Scribble.xaml?action=edit", UriKind.Relative));
      //Do work for your application here.
    }

    const string FNAME = "data.dat";

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
      base.OnNavigatedTo(e);

      using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
      {
        ((ApplicationBarIconButton)ApplicationBar.Buttons[1]).IsEnabled = isf.FileExists(FNAME);
      }

      moveNameStoryboard.Begin();
    }

    // Constructor
    public MainPage()
    {
      InitializeComponent();
    }
  }
}