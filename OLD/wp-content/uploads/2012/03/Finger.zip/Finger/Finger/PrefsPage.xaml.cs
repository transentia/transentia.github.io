﻿using System;
using Microsoft.Phone.Controls;
using System.Windows.Media;
using System.Windows.Navigation;

namespace Finger
{
  public partial class PrefsPage : PhoneApplicationPage
  {
    private Color selectedColor;

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
      base.OnNavigatedTo(e);
      colorPicker.Color = (((App)App.Current).Resources["appSettings"] as AppSettings).ColorSetting;
     // Console.WriteLine("***Prefs START OnNavigatedTo: " +  colorPicker.Color + " sel: " + selectedColor);
    }
     
    private void Picker_ColorChanged(object sender, Color color)
    {
      //Console.WriteLine("***Picker_ColorChanged: " + color);
      this.selectedColor = color;
    }

    private void Back_Click(object sender, EventArgs e)
    {
      NavigationService.GoBack();
    }

    private void Save_Click(object sender, EventArgs e)
    {
      //Console.WriteLine("***Save_Click: " + selectedColor);
      (((App)App.Current).Resources["appSettings"] as AppSettings).ColorSetting = selectedColor;
      NavigationService.GoBack();
    }

    public PrefsPage()
    {
      InitializeComponent();
    }
  }
}