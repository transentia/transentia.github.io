﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;
using System.Runtime.Serialization;
using System.IO.IsolatedStorage;
using System.IO;
using System.Xml.Serialization;
using System.Windows.Resources;
using System.Windows.Media.Imaging;
using Microsoft.Phone.Shell;

namespace Finger
{
  [DataContract]
  public class MyLine
  {
    public MyLine() { }
    [DataMember]
    public Color color { get; set; }
    [DataMember]
    public double X1 { get; set; }
    [DataMember]
    public double Y1 { get; set; }
    [DataMember]
    public double X2 { get; set; }
    [DataMember]
    public double Y2 { get; set; }
  }

  public class MyList
  {
    public MyList() { list = new List<MyLine>(); }

    public List<MyLine> list { get; set; }

    public void Add(Point currentPoint, Point oldPoint, Color c)
    {
      list.Add(new MyLine()
      {
        X1 = currentPoint.X,
        Y1 = currentPoint.Y,
        X2 = oldPoint.X,
        Y2 = oldPoint.Y,
        color = c
      });
    }

    const string FNAME = "data.dat";

    public void Store()
    {
      Console.WriteLine("***START Store, list.Count: " + list.Count);

      using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
      {
        //if (isf.FileExists(FNAME))
        //  isf.DeleteFile(FNAME);
        using (IsolatedStorageFileStream isfStream = new IsolatedStorageFileStream(FNAME, FileMode.Create, isf))
        {
          XmlSerializer serializer = new XmlSerializer(typeof(List<MyLine>));
          serializer.Serialize(isfStream, list);
        }
      }

      Console.WriteLine("***END Store, list.Count: " + list.Count);
    }

    public void Load()
    {
      Console.WriteLine("***START Load, list.Count: " + list.Count);

      using (IsolatedStorageFile isf = IsolatedStorageFile.GetUserStoreForApplication())
      using (IsolatedStorageFileStream isfStream = new IsolatedStorageFileStream("data.dat", FileMode.OpenOrCreate, isf))
      {
        if (isfStream.Length > 0)
        {
          XmlSerializer serializer = new XmlSerializer(typeof(List<MyLine>));
          list = (List<MyLine>)serializer.Deserialize(isfStream);
        }
      }

      Console.WriteLine("***END Load, list.Count: " + list.Count);
    }
  }

  public partial class Scribble : PhoneApplicationPage
  {
    MyList myList = new MyList();
    Point oldPoint;

    protected override void OnNavigatedFrom(NavigationEventArgs e)
    {
      base.OnNavigatedFrom(e);

      Console.WriteLine("***START OnNavigatedFrom");

      myList.Store();
      CreateOrUpdateTile();

      Console.WriteLine("***END OnNavigatedFrom");
    }

    private const string tempJPEG = "/Shared/ShellContent/tile.jpg";

    private void CreateOrUpdateTile()
    {
      using (IsolatedStorageFile myStore = IsolatedStorageFile.GetUserStoreForApplication())
      {
        if (myStore.FileExists(tempJPEG))
          myStore.DeleteFile(tempJPEG);

        using (IsolatedStorageFileStream myFileStream = myStore.CreateFile(tempJPEG))
        {
          WriteableBitmap wbmp = new WriteableBitmap(ContentPanelCanvas, null); 

          // Encode the WriteableBitmap object to a JPEG stream.
          Extensions.SaveJpeg(wbmp, myFileStream, wbmp.PixelWidth, wbmp.PixelHeight, 0, 85);
        }

        //MessageBox.Show("saved");

        using (IsolatedStorageFileStream myFileStream = myStore.OpenFile(tempJPEG, FileMode.Open, FileAccess.Read))
        {
          ShellTile TileToFind = ShellTile.ActiveTiles.First();

          // Create the Tile if we didn't find that it already exists.
          if (TileToFind == null)
            return;

          // Create the Tile object and set some initial properties for the Tile.
          // The Count value of 12 shows the number 12 on the front of the Tile. Valid values are 1-99.
          // A Count value of 0 indicates that the Count should not be displayed.
          StandardTileData NewTileData = new StandardTileData
          {
            BackBackgroundImage = new Uri("isostore:" + tempJPEG, UriKind.Absolute),
            //BackBackgroundImage = new Uri("/icons/appbar.add.rest.png", UriKind.Relative),
            Count = DateTime.Now.Second,
            BackTitle = string.Format("{0}", DateTime.Now)
          };

          TileToFind.Update(NewTileData);

          //MessageBox.Show("Updated");
        }
      }
    }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
      base.OnNavigatedTo(e);

      Console.WriteLine("***START OnNavigatedTo");

      string action = "";

      if (NavigationContext.QueryString.TryGetValue("action", out action))
        switch (action)
        {
          case "edit":
            myList.Load();
            foreach (MyLine ml in myList.list)
            {
              var l = new Line()
              {
                Stroke = new SolidColorBrush(ml.color),
                StrokeThickness = 5,
                X1 = ml.X1,
                Y1 = ml.Y1,
                X2 = ml.X2,
                Y2 = ml.Y2
              };
              ContentPanelCanvas.Children.Add(l);
            }
            break;
          case "add":
          default: /* nothing to do */ break;
        }

      Console.WriteLine("***START OnNavigatedTo");
    }

    public Scribble()
    {
      InitializeComponent();

      var c = (((App)App.Current).Resources["appSettings"] as AppSettings).ColorSetting;

      ContentPanelCanvas.MouseMove += (s, e) =>
      {
        var canvas = s as Canvas;
        var currentPoint = e.GetPosition(canvas);
        var l = new Line()
        {
          Stroke = new SolidColorBrush(c),
          StrokeThickness = 5,
          X1 = currentPoint.X,
          Y1 = currentPoint.Y,
          X2 = oldPoint.X,
          Y2 = oldPoint.Y
        };
        canvas.Children.Add(l);

        myList.Add(currentPoint, oldPoint, c);

        oldPoint = currentPoint;
      };

      ContentPanelCanvas.MouseLeftButtonDown += (s, e) =>
      {
        oldPoint = e.GetPosition(s as Canvas);
      };
    }
  }
}