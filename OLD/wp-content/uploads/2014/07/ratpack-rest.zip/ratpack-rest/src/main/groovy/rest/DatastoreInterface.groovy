package rest

interface DatastoreInterface {
    List<Feline> list(Map params)
    Feline get(Long id)
    Feline add(Feline f)
    boolean update(Feline f)
    boolean delete(Long id)
    Long size()
}
