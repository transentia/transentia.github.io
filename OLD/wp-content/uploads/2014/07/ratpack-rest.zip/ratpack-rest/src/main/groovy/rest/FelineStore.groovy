package rest

import java.util.logging.Logger

class FelineStore implements DatastoreInterface {
    private static final Logger logger = Logger.getLogger(FelineStore.canonicalName)

    private final Object[] dbLock = new Object[0]

    private List<Feline> database = []

    private final EMPTY_RANGE = 0..<0

    private def pagination(params) {
        def r = EMPTY_RANGE
        if (params.max && params.offset) {
            def max = params.max as Integer  // ignore possibility of non-numeric errors
            def off = params.offset as Integer
            def sz = database.size()
            r = (max <= 0 || off < 0) ? EMPTY_RANGE : Math.min(off, sz)..<Math.min(off + max, sz)
        }
        r
    }

    @Override
    List<Feline> list(Map params) {
        synchronized (dbLock) {
            database[pagination(params)]
        }
    }

    @Override
    Feline get(Long id) { database.find { it.id == id } }

    private final felineComparator = [compare: { a, b -> a.id <=> b.id }] as Comparator<Feline>

    @Override
    Feline add(Feline f) {
        synchronized (dbLock) {
            f.id = (database.max(felineComparator)?.id ?: 0L) + 1
            database << f
            f
        }
    }

    @Override
    boolean update(Feline f) {
        def found = get(f.id)
        found?.with { o ->
            o.name = f.name ?: o.name
            o.description = f.description ?: o.description
            o.age = f.age ?: o.age
            o.deceased = f.deceased ?: o.deceased
        }
        found != null
    }

    @Override
    boolean delete(Long id) {
        def found
        synchronized (dbLock) {
            found = get(id)
            if (found)
                database -= found
        }
        found != null
    }

    @Override
    Long size() {
        synchronized (dbLock) {
            database.size()
        }
    }
}
