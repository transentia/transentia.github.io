import rest.*

import static ratpack.groovy.Groovy.groovyTemplate
import ratpack.jackson.JacksonModule
import static ratpack.jackson.Jackson.json
import static ratpack.groovy.Groovy.ratpack
import com.google.inject.AbstractModule
import static com.google.inject.Scopes.SINGLETON

ratpack {
    bindings {
        add new JacksonModule()
        add new AbstractModule() {

            @Override
            protected void configure() {
                bind(FelineStore).in(SINGLETON)
            }
        }

        // a few fixtures
        init { FelineStore felineStore ->
            felineStore.add(new Feline(id: 0, name: "Scotty", age: 5, description: "Active young(ish) male", deceased: Boolean.FALSE))
            felineStore.add(new Feline(id: 1, name: "Furball", age: 5, description: "Fluffy!", deceased: Boolean.TRUE))
            felineStore.add(new Feline(id: 2, name: "Blackie", age: 6, description: "Black and very affectionate!", deceased: Boolean.FALSE))
            felineStore.add(new Feline(id: 3, name: "Midnight", age: 4, description: "Shy male!", deceased: Boolean.FALSE))
            felineStore.add(new Feline(id: 4, name: "Julius", age: 6, description: "Can clearly say 'Hello!", deceased: Boolean.FALSE))
            felineStore.add(new Feline(id: 5, name: "Meow Meow", age: 10, description: "Getting on a bit", deceased: Boolean.FALSE))

            String.metaClass.safeParseAsLong = {
                try {
                    delegate as Long
                }
                catch (e) {
                    null
                }
            }
        }
    }

    handlers { FelineStore datastore ->
        get("api/felines/count") {
            blocking {
                datastore.size()
            }
            .then {
                render json(count: it)
            }
        }
        handler("api/felines/:id?") {
            def id = pathTokens.id?.safeParseAsLong()
            byMethod {
                get {
                    blocking {
                        id ? datastore.get(id) : datastore.list(request.queryParams)
                    }
                    .then {
                        if (it != null)
                            render json(it)
                        else {
                            clientError(404)
                        }
                    }
                }
                post {
                    blocking {
                        def f = parse Feline
                        datastore.add(f)
                    }
                    .then {
                        render json(it)
                    }
                }
                delete {
                    blocking {
                        id ? datastore.delete(id) : null
                    }
                    .then {
                        clientError(it ? 204 : 404)
                    }
                }
                put {
                    blocking {
                        def f = parse Feline
                        f.id = id
                        f.id ? datastore.update(f) : null
                    }
                    .then {
                        clientError(it ? 204 : 404)
                    }
                }
            }
        }
        get {
            render groovyTemplate("grid.html", title: "AngularJS + Ng-grid + Bootstrap + Ratpack REST")
        }

        assets "public"
    }
}
