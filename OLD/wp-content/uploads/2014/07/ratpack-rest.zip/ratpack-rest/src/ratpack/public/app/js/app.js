(function() {
  var app;

  app = angular.module('rest', ['ui.bootstrap', 'ngGrid', 'rest.controllers']).config(function($locationProvider) {
    return $locationProvider.html5Mode(true);
  });

}).call(this);
