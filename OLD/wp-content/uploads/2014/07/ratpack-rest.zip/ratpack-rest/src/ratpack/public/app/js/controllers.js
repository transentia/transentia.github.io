(function() {
  var controllers;

  controllers = angular.module('rest.controllers', ['ngResource']);

  controllers.controller('ServantListCtrl', function($scope, $modal, $resource, $http, $log) {
    var ModalCreateEditCtrl, ModalRmCtrl, cellTmpl, clearErrMsg, col0HeaderCellTemplate, resource, setErrMsg;
    resource = $resource('api/felines/:id', {}, {
      'update': {
        method: 'PUT'
      }
    });
    resource.fetchCount = function() {
      return $http({
        method: 'GET',
        url: 'api/felines/count'
      }).success(function(data) {
        return $scope.totalItems = data.count;
      }).error(function(_, status) {
        return setErrMsg("Get/Count ERROR: " + status);
      });
    };
    $scope.errorMessage = void 0;
    clearErrMsg = function() {
      return $scope.errorMessage = "";
    };
    setErrMsg = function(m) {
      return $scope.errorMessage = m;
    };
    $scope.selectedRow = [];
    $scope.felines = [];
    $scope.totalItems = 0;
    $scope.currentPage = 1;
    $scope.itemsPerPage = 5;
    $scope.getPagedDataAsync = function() {
      return setTimeout(function() {
        return resource.query({
          offset: $scope.itemsPerPage * ($scope.currentPage - 1),
          max: $scope.itemsPerPage,
          sort: "id",
          order: "asc"
        }, function(value) {
          $scope.felines = value;
          return resource.fetchCount();
        }, function(httpResponse) {
          return setErrMsg("Query ERROR: " + httpResponse.statusText);
        });
      }, 10);
    };
    cellTmpl = '<div class="ngCellText ng-scope col0 colt0" ng-class="col.colIndex()">\n    <span ng-cell-text="" class="ng-binding">\n        <button type="button" class="btn btn-default btn-xs" ng-click="rm(row.entity)">\n            <span class="glyphicon glyphicon-minus"></span>\n        </button>\n        <button type="button" class="btn btn-default btn-xs" ng-click="edit(row.entity)">\n            <span class="glyphicon glyphicon-pencil"></span>\n        </button>\n    </span>\n</div>';
    col0HeaderCellTemplate = '<div class="ngHeaderSortColumn ngCellText {{col.headerClass}}"">\n    <span ng-cell-text="" class="ng-binding">\n        <div>\n            <button type="button" class="btn btn-default btn-xs" ng-click="create()">\n                <span class="glyphicon glyphicon-plus"></span>\n            </button>\n        </div>\n    </span>\n</div>';
    $scope.gridOptions = {
      totalServerItems: 'totalServerItems',
      data: 'felines',
      columnDefs: [
        {
          field: '',
          displayName: '',
          width: '64px',
          sortable: false,
          enableCellEdit: false,
          resizable: false,
          cellTemplate: cellTmpl,
          headerCellTemplate: col0HeaderCellTemplate
        }, {
          field: 'id',
          displayName: 'ID',
          width: "**",
          resizable: false
        }, {
          field: 'name',
          displayName: 'Name',
          width: "***",
          resizable: false
        }, {
          field: 'age',
          displayName: 'Age',
          width: "*",
          resizable: false
        }, {
          field: 'deceased',
          displayName: 'Dead',
          width: "*",
          resizable: false
        }, {
          field: 'description',
          displayName: 'Description',
          width: "**********"
        }
      ],
      selectedItems: $scope.selectedRow,
      enableSorting: false,
      multiSelect: false,
      showFooter: false
    };
    $scope.getPagedDataAsync();
    $scope.$on('ngGridEventData', function() {
      return $scope.gridOptions.selectRow(0, true);
    });
    $scope.create = function() {
      var modalInstance;
      clearErrMsg();
      modalInstance = $modal.open({
        templateUrl: 'modalEditCreateForm.tmpl',
        controller: ModalCreateEditCtrl,
        resolve: {
          modalMode: function() {
            return 'create';
          },
          row: function() {
            return {
              name: "",
              age: 0,
              deceased: false,
              description: ""
            };
          }
        }
      });
      return modalInstance.result.then(function(e) {
        return resource.save(e, (function() {
          return $scope.getPagedDataAsync();
        }), (function(httpResponse) {
          return setErrMsg("Save ERROR: " + httpResponse.statusText);
        }));
      });
    };
    $scope.rm = function(e) {
      var modalInstance;
      clearErrMsg();
      modalInstance = $modal.open({
        templateUrl: 'modalRmForm.tmpl',
        controller: ModalRmCtrl,
        resolve: {
          row: function() {
            return e;
          }
        }
      });
      return modalInstance.result.then(function(e) {
        return e.$remove({
          id: e.id
        }, (function() {
          return $scope.getPagedDataAsync();
        }), (function(httpResponse) {
          return setErrMsg("Remove ERROR: " + httpResponse.statusText);
        }));
      });
    };
    $scope.edit = function(e) {
      var modalInstance;
      clearErrMsg();
      modalInstance = $modal.open({
        templateUrl: 'modalEditCreateForm.tmpl',
        controller: ModalCreateEditCtrl,
        resolve: {
          modalMode: function() {
            return 'edit';
          },
          row: function() {
            return angular.copy(e);
          }
        }
      });
      return modalInstance.result.then(function(e) {
        var oldId, x, _i, _len, _ref;
        oldId = e.id;
        _ref = ['class', 'felines', 'servant', 'id'];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          x = _ref[_i];
          delete e[x];
        }
        return e.$update({
          id: oldId
        }, (function() {
          return $scope.getPagedDataAsync();
        }), (function(httpResponse) {
          return setErrMsg("Edit ERROR: " + httpResponse.statusText);
        }));
      });
    };
    ModalRmCtrl = function($scope, $modalInstance, row) {
      $scope.row = row;
      $scope.ok = function() {
        return $modalInstance.close(row);
      };
      return $scope.cancel = function() {
        return $modalInstance.dismiss('cancel');
      };
    };
    return ModalCreateEditCtrl = function($scope, $modalInstance, row, modalMode) {
      $scope.row = row;
      $scope.modalMode = modalMode;
      $scope.ok = function() {
        return $modalInstance.close(row);
      };
      return $scope.cancel = function() {
        return $modalInstance.dismiss('cancel');
      };
    };
  });

}).call(this);
