import bk.geom.rotatingcalipers.Point
import bk.geom.rotatingcalipers.Polygon
import bk.geom.rotatingcalipers.RotatingCalipers
import java.awt.image.BufferedImage
import javax.swing.ImageIcon
import javax.swing.JFileChooser
import javax.swing.filechooser.FileFilter
import java.awt.*
import java.awt.geom.AffineTransform
import java.awt.image.AffineTransformOp
import javax.imageio.ImageIO
import java.awt.geom.PathIterator
import javax.swing.filechooser.FileSystemView

class GTController {

  def model
  def view
  def builder

  private fileChooser
  private defaultDestIcon

  void mvcGroupInit(Map args) {
    model.polygon = new Polygon()

    model.image = builder.imageIcon('/griffon.png')
    defaultDestIcon = builder.imageIcon('/griffon.png')
    model.destinationImage = builder.imageIcon('/griffon.png')

    fileChooser = builder.fileChooser(fileSelectionMode: JFileChooser.FILES_ONLY,
                                      currentDirectory: FileSystemView.fileSystemView.homeDirectory)
  }

  // This method returns a buffered image with the contents of an image
  private static BufferedImage toBufferedImage(Image image) {
    if (image instanceof BufferedImage) {
      return (BufferedImage) image;
    }

    // This code ensures that all the pixels in the image are loaded
    image = new ImageIcon(image).getImage();

    // Create a buffered image with a format that's compatible with the screen
    BufferedImage bimage = null;
    GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
    try {
      // Create the buffered image
      GraphicsDevice gs = ge.getDefaultScreenDevice();
      GraphicsConfiguration gc = gs.getDefaultConfiguration();
      bimage = gc.createCompatibleImage(
          image.getWidth(null), image.getHeight(null), Transparency.OPAQUE);
    } catch (HeadlessException e) {
      // The system does not have a screen
    }

    if (bimage == null) {
      bimage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
    }

    // Copy image to buffered image
    Graphics g = bimage.createGraphics();

    // Paint the image onto the buffered image
    g.drawImage(image, 0, 0, null);
    g.dispose();

    return bimage;
  }

  private findIndexOfLeftMostAndAdjacentPoints(p) {
    def pi = p.getPathIterator(null)
    def array = new double[6]
    def index = 0
    def foundIndex = -1
    def minX = Integer.MAX_VALUE
    while (!pi.isDone()) {
      int value = pi.currentSegment(array);
      def x = array[0]
      switch (value) {
        case PathIterator.SEG_LINETO:
        case PathIterator.SEG_MOVETO:
          if (x < minX) {
            foundIndex = index
            minX = x
          }
      }
      index++
      pi.next()
    }
    [foundIndex, (foundIndex + 1) % (index - 2)]
  }

  private findCenter(p) {
    def x
    def y
    p.bounds.with {b ->
      x = b.x + (b.width / 2)
      y = b.y + (b.height / 2)
    }
    [x, y]
  }

  private findRotation(x0, y0, x1, y1) {
    def adj = x1 - x0
    def opp = y1 - y0
    def rot = Math.atan(adj / opp)
    (rot > Math.toRadians(45)) ? -(Math.toRadians(90) - rot) : rot
  }

  private getPoint(p, i) {
    [p.xpoints[i], p.ypoints[i]]
  }

  // Origins of RotatingCalipers stuff...
  // http://www.iruimte.nl/calipers/
  // 'Bart' aka user 'prometheuzz', http://forums.sun.com/profile.jspa?userID=550123
  // http://forums.sun.com/thread.jspa?threadID=569609&start=15&tstart=0

  // has side-effect of updating the source image to display bouding rectangle and various
  // important points
  def extractSubimage = {image ->
    def rc = new RotatingCalipers(model.polygon)
    def ser = rc.rectangles[rc.indexSmallestRectangle]
    model.boundingPolygon = new java.awt.Polygon()
    (0..4).each {
      model.boundingPolygon.addPoint((int) ser.xPoints[it], (int) ser.yPoints[it])
    }

    def (int centerX, int centerY) = findCenter(model.boundingPolygon)
    model.boundingPolygonCenterX = centerX
    model.boundingPolygonCenterY = centerY
    def (int leftMost, int leftMostAdjacent) = findIndexOfLeftMostAndAdjacentPoints(model.boundingPolygon)
    def (int leftX, int leftY) = getPoint(model.boundingPolygon, leftMost)
    model.boundingPolygonLeftX = leftX
    model.boundingPolygonLeftY = leftY
    def (int prevLeftX, int prevLeftY) = getPoint(model.boundingPolygon, leftMostAdjacent)
    model.boundingPolygonPrevLeftX = prevLeftX
    model.boundingPolygonPrevLeftY = prevLeftY
    double rotation = findRotation(leftX, leftY, prevLeftX, prevLeftY)

    view.background.repaint()

    def bufferedImage = toBufferedImage(image)

    def (transform, op) = trans(rotation, centerX, centerY)
    bufferedImage = op.filter(bufferedImage, null)
    def trfAwtPolygon = transform.createTransformedShape(model.boundingPolygon)

    trfAwtPolygon.bounds.with {b ->
      bufferedImage = bufferedImage.getSubimage((int) b.x, (int) b.y, (int) b.width, (int) b.height)
    }

    return new ImageIcon(bufferedImage)
  }

  def trans(rot, x, y) {
    def transform = new AffineTransform()
    transform.rotate(rot, x, y)
    def op = new AffineTransformOp(transform, AffineTransformOp.TYPE_BILINEAR)
    [transform, op]
  }

  def extractActionClosure = {evt = null ->
    try {
      doOutside {
        model.destinationImage = extractSubimage(view.background.image.image)
      }
      model.saveAsEnabled = true
      model.labelText = "Extract OK..."
    } catch (Exception e) {
      model.labelText = "Cannot extract: '$e.message'"
    }
  }

  def clearActionClosure = {evt = null ->
    model.polygon.clear()
    model.boundingPolygon.reset()
    model.sufficientPointsForExtraction = false
    model.saveAsEnabled = false
    view.background.repaint()
    model.destinationImage = defaultDestIcon
    model.labelText = "Cleared..."
  }

  def mousePressedAction = {evt = null ->
    // ignore clicks outside the image, which is always at (0,0)
    if ((evt.point.y >= view.background.image.iconHeight) ||
        (evt.point.x >= view.background.image.iconWidth))
      return

    def pp = new Point((int) evt.point.x, (int) evt.point.y)
    def found = model.polygon.points.findAll { it.distance(pp) <= 8 }
    if (found) {// != null) {
      model.polygon.removePoint(found[0])
      model.boundingPolygon.reset()
      }
    else
    {
      if (model.sufficientPointsForExtraction)
        return

      model.polygon.addPoint(pp)
    }
    model.labelText = model.polygon.toString()
    model.sufficientPointsForExtraction = model.polygon.size() >= 4
    view.background.repaint()
  }

  def openFile(File file) {
    doOutside {
      model.file = file
      doLater {
        clearActionClosure()
        model.image = builder.imageIcon(file.path)
      }
    }
  }

  def saveAsActionClosure = {evt = null ->
    def file = selectFileForSave()
    if (!file)
      return
    ImageIO.write(view.destination.icon.image, "png", file)
    model.labelText = "Saved as $file.name..."
  }

  // I find it clearer to NOT refactor these mirror*/rotate* methods
  // the resulting code is a bit obscure...
  def mirrorYActionClosure = {evt = null ->
    doOutside {
      def img = toBufferedImage(model.destinationImage.image)
      AffineTransform transform = AffineTransform.getScaleInstance(1, -1)
      transform.translate(0, -img.height)
      AffineTransformOp op = new AffineTransformOp(transform, AffineTransformOp.TYPE_BILINEAR)
      img = op.filter(img, null)
      edt {
        model.destinationImage = new ImageIcon(img)
      }
    }
  }

  def mirrorXActionClosure = {evt = null ->
    doOutside {
      def img = toBufferedImage(model.destinationImage.image)
      AffineTransform transform = AffineTransform.getScaleInstance(-1, 1)
      transform.translate(-img.width, 0)
      AffineTransformOp op = new AffineTransformOp(transform, AffineTransformOp.TYPE_BILINEAR)
      img = op.filter(img, null)
      edt {
        model.destinationImage = new ImageIcon(img)
      }
    }
  }

  def rotate90LeftActionClosure = {evt = null ->
    doOutside {
      def img = toBufferedImage(model.destinationImage.image)
      def newImage = new BufferedImage(model.destinationImage.iconHeight,
                                       model.destinationImage.iconWidth, BufferedImage.TYPE_INT_ARGB);
      def g2d = newImage.createGraphics()
      g2d.translate 0, model.destinationImage.iconWidth
      g2d.rotate(-Math.PI / 2)
      g2d.drawImage img, 0, 0, null
      g2d.dispose()
      edt {
        model.destinationImage = new ImageIcon(newImage)
      }
    }
  }

  def rotate90RightActionClosure = {evt = null ->
    doOutside {
      def img = toBufferedImage(model.destinationImage.image)
      def newImage = new BufferedImage(model.destinationImage.iconHeight,
                                       model.destinationImage.iconWidth, BufferedImage.TYPE_INT_ARGB);
      def g2d = newImage.createGraphics()
      g2d.translate model.destinationImage.iconHeight, 0
      g2d.rotate(Math.PI / 2)
      g2d.drawImage img, 0, 0, null
      g2d.dispose()
      edt {
        model.destinationImage = new ImageIcon(newImage)
      }
    }
  }

  def open = {evt = null ->
    def file = selectFileForOpen()
    if (!file)
      return
    openFile(file)
  }

  def exit = {evt = null ->
    app.shutdown()
  }

  private selectFileForSave() {
    fileChooser.dialogTitle = "Save to PNG"
    fileChooser.selectedFile = new File("${new Date().time}.png")
    (fileChooser.showSaveDialog() == JFileChooser.APPROVE_OPTION) ? fileChooser.selectedFile : null
  }

  private selectFileForOpen() {
    fileChooser.dialogTitle = "Open"
    ImagePreviewPanel
    ImagePreviewPanel preview = new ImagePreviewPanel()
    fileChooser.accessory = preview
    fileChooser.addPropertyChangeListener(preview)
    fileChooser.fileFilter = [getDescription: {-> "All Images"}, accept:{file-> file ==~ /(?i).*?\.(png|gif|jpg||jpeg)/ || file.isDirectory() }] as FileFilter
    (fileChooser.showOpenDialog() == JFileChooser.APPROVE_OPTION) ? fileChooser.selectedFile : null
  }

  def aboutActionClosure = {evt = null ->
    def pane = builder.optionPane(icon: builder.imageIcon('/griffon-icon-64x64.png'),
                                  message: """Welcome to GT.

GT is an application that makes it easy to isolate portions of an image,
regardless of rotation.

Built with Groovy/Griffon!

Built: 2009 May 26 by bob@transentia.com.au.""")
    def dialog = pane.createDialog(app.appFrames[0], "About GT")
    dialog.show()
  }
}
