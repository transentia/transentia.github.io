import groovy.beans.Bindable

import javax.swing.ImageIcon

class GTModel {
  @Bindable bk.geom.rotatingcalipers.Polygon polygon
  @Bindable java.awt.Polygon boundingPolygon = new java.awt.Polygon()
  @Bindable int boundingPolygonCenterX
  @Bindable int boundingPolygonCenterY
  @Bindable int boundingPolygonLeftX
  @Bindable int boundingPolygonLeftY
  @Bindable int boundingPolygonPrevLeftX
  @Bindable int boundingPolygonPrevLeftY
  @Bindable boolean sufficientPointsForExtraction = false
  @Bindable boolean saveAsEnabled = false
  @Bindable String file
  @Bindable ImageIcon image
  @Bindable ImageIcon destinationImage
  @Bindable String labelText = 'Welcome!'
}


