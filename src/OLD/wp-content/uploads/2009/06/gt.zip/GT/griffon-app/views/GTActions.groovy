import groovy.ui.Console

actions {
  action(id: 'openAction',
         name: 'Open...',
         closure: controller.open,
         mnemonic: 'O',
         accelerator: shortcut('O'),
         smallIcon: imageIcon(resource: "icons/folder_page.png", class: Console),
         shortDescription: 'Open an Image'
  )
  action(id: 'exitAction',
         name: 'Exit',
         closure: controller.exit,
         mnemonic: 'X',
  )
  action(id: 'extractAction',
         name: 'Extract',
         mnemonic: 'T',
         accelerator: shortcut('T'),
         enabled: bind { model.sufficientPointsForExtraction },
         closure: controller.extractActionClosure
  )
  action(id: 'clearAction',
         name: 'Clear',
         mnemonic: 'R',
         accelerator: shortcut('R'),
         enabled: true,
         closure: controller.clearActionClosure
  )
  action(id: 'saveAsAction',
         name: 'Save As...',
         mnemonic: 'S',
         smallIcon: builder.imageIcon("/disk.png"),
         accelerator: shortcut('S'),
         enabled: bind { model.saveAsEnabled },
         closure: controller.saveAsActionClosure
  )
  action(id: 'rotate90LeftAction',
         name: 'Rotate Left',
         mnemonic: 'L',
         smallIcon: builder.imageIcon('/shape_rotate_anticlockwise.png'),
         enabled: bind { model.saveAsEnabled },
         closure: controller.rotate90LeftActionClosure
  )
  action(id: 'rotate90RightAction',
         name: 'Rotate Right',
         mnemonic: 'R',
         smallIcon: builder.imageIcon('/shape_rotate_clockwise.png'),
         enabled: bind { model.saveAsEnabled },
         closure: controller.rotate90RightActionClosure
  )
  action(id: 'mirrorYAction',
         name: 'Mirror on Y Axis',
         smallIcon: builder.imageIcon('/shape_flip_vertical.png'),
         enabled: bind { model.saveAsEnabled },
         closure: controller.mirrorYActionClosure
  )
  action(id: 'mirrorXAction',
         name: 'Mirror on X Axis',
         smallIcon: builder.imageIcon('/shape_flip_horizontal.png'),
         enabled: bind { model.saveAsEnabled },
         closure: controller.mirrorXActionClosure
  )
  action(id: 'aboutAction',
         name: 'About',
         mnemonic: 'A',
         closure: controller.aboutActionClosure
  )
}
