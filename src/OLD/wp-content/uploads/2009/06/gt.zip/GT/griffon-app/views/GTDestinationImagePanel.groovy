import static java.awt.BorderLayout.*
import javax.swing.JLabel
import java.awt.Color
import org.jdesktop.swingx.painter.PinstripePainter

jxheader(title: "Destination",
         description: 'Display and manipulate the isolated portion of the source image.',
         border: emptyBorder(4),
         constraints: NORTH)
scrollPane(id: 'scrollPane',
           constraints: CENTER) {
  jxlabel(id: 'destination',
          icon: bind { model.destinationImage },
          constraints: CENTER,
          horizontalAlignment: JLabel.CENTER_ALIGNMENT,
          border: loweredBevelBorder(),
          backgroundPainter: new PinstripePainter(Color.LIGHT_GRAY))
}
hbox(constraints: SOUTH, border: emptyBorder(4)) {
  button(rotate90LeftAction, text: '')
  hstrut(8)
  button(rotate90RightAction, text: '')
  hstrut(8)
  button(mirrorXAction, text: '')
  hstrut(8)
  button(mirrorYAction, text: '')
  hglue()
  button(saveAsAction)
}
