import static griffon.util.GriffonApplicationUtils.*

menuBar = menuBar {
  if (!isMacOSX) {
    menu(text: 'File', mnemonic: 'F') {
      menuItem(exitAction)
    }
  }
  menu(text: 'Source', mnemonic: 'S') {
    menuItem(openAction)
    separator()
    menuItem(extractAction)
    menuItem(clearAction)
  }
  menu(text: 'Destination', mnemonic: 'D') {
    menuItem(saveAsAction)
    separator()
    menuItem(rotate90LeftAction)
    menuItem(rotate90RightAction)
    menuItem(mirrorXAction)
    menuItem(mirrorYAction)
  }
  if (!isMacOSX) {
    glue()
    menu(text: 'Help', mnemonic: 'H') {
      menuItem(aboutAction)
    }
  }

}

return menuBar
