import static java.awt.BorderLayout.*

ip = new SourceImagePanel(border: raisedBevelBorder(),
                          mousePressed: controller.mousePressedAction)
bind(source: model, sourceProperty: 'image', target: ip, targetProperty: 'image')
bind(source: model, sourceProperty: 'polygon', target: ip, targetProperty: 'polygon')
bind(source: model, sourceProperty: 'boundingPolygon', target: ip, targetProperty: 'boundingPolygon')
bind(source: model, sourceProperty: 'boundingPolygonCenterX', target: ip, targetProperty: 'boundingPolygonCenterX')
bind(source: model, sourceProperty: 'boundingPolygonCenterY', target: ip, targetProperty: 'boundingPolygonCenterY')
bind(source: model, sourceProperty: 'boundingPolygonLeftX', target: ip, targetProperty: 'boundingPolygonLeftX')
bind(source: model, sourceProperty: 'boundingPolygonLeftY', target: ip, targetProperty: 'boundingPolygonLeftY')
bind(source: model, sourceProperty: 'boundingPolygonPrevLeftX', target: ip, targetProperty: 'boundingPolygonPrevLeftX')
bind(source: model, sourceProperty: 'boundingPolygonPrevLeftY', target: ip, targetProperty: 'boundingPolygonPrevLeftY')

jxheader(title: 'source',
         description: 'Isolate portions of the image loaded here',
         border: emptyBorder(4),
         constraints: NORTH)
scrollPane(id: 'scrollPane',
           constraints: CENTER) {
  widget(id: 'background', ip)
}
hbox(constraints: SOUTH, border: emptyBorder(4)) {
  button(openAction)
  hstrut(16)
  button(extractAction)
  hstrut(8)
  button(clearAction)
}


