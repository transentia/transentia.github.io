import static java.awt.BorderLayout.*
import javax.swing.JSplitPane
import java.awt.Color

build(GTActions)

application(title: 'GT',
            //size:[320,480],
            pack: true,
            //location:[50,50],
            locationByPlatform: true,
            iconImage: imageIcon('/griffon-icon-48x48.png').image,
            iconImages: [imageIcon('/griffon-icon-48x48.png').image,
            imageIcon('/griffon-icon-32x32.png').image,
            imageIcon('/griffon-icon-16x16.png').image]
) {

  menuBar(build(GTMenuBar))

  panel(border: emptyBorder(6)) {
    borderLayout()
    splitPane(id: "splitter",
              preferredSize: [1024, 768],
              dividerLocation: 512,
              orientation: JSplitPane.HORIZONTAL_SPLIT,
              constraints: CENTER,
              border: lineBorder(color: Color.BLACK, thickness: 1)) {
      panel(id: 'sourceImagePanel') {
        borderLayout()
        build(GTSourceImagePanel)
      }
      panel(id: 'destinationImagePanel') {
        borderLayout()
        build(GTDestinationImagePanel)
      }
    }
    label(id: 'status',
          constraints: SOUTH,
          border: emptyBorder(4),
          text: bind { model.labelText })
  }
}

