import java.awt.Graphics
import java.awt.Color
import bk.geom.rotatingcalipers.Polygon
import bk.geom.rotatingcalipers.Point
import javax.swing.JPanel
import java.awt.Dimension
import java.awt.Graphics2D
import java.awt.AlphaComposite
import java.awt.Composite

public class SourceImagePanel extends JPanel {

  def polygon
  def image
  def boundingPolygon
  int boundingPolygonCenterX
  int boundingPolygonCenterY
  int boundingPolygonLeftX
  int boundingPolygonLeftY
  int boundingPolygonPrevLeftX
  int boundingPolygonPrevLeftY

  @Override
  public Dimension getPreferredSize() {
    if (!image)
      return super.preferredSize

    return new Dimension(image.width, image.height)
  }

  def getColor(n) {
    switch (n) {
      case 2..3: return Color.RED
      case 4: return Color.GRAY
    }
  }

  private AlphaComposite makeComposite(float alpha) {
    return AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha)
  }

  // marker shape info
  private final int SS = 6
  private final int HSS = (SS / 2)
  private final int BS = 8
  private final int HBS = (BS / 2)

  @Override
  protected void paintComponent(Graphics g) {
    if (!isVisible()) {
      return;
    }

    super.paintComponent(g)

    g.drawImage image?.image, 0, 0, null

    g.color = Color.BLUE
    for (Point p: polygon.points)
      g.fillOval p.x - HSS, p.y - HSS, SS, SS

    def nPoints = polygon.points.size()
    g.color = getColor(nPoints)
    if (nPoints == 2) {
      def (p_0, p_1) = polygon.points[0..1]
      g.drawLine p_0.x, p_0.y, p_1.x, p_1.y
    } else
      if (!polygon.allPointsCollinear() && nPoints >= 3) {

        Polygon hull = polygon.convexHull
        for (int i = 0; i < hull.points.size() - 1; i++) {
          def (p_0, p_1) = hull.points[i..i + 1]
          g.drawLine p_0.x, p_0.y, p_1.x, p_1.y
        }
      }

    if (boundingPolygon?.npoints) {
      g.color = Color.BLUE
      g.drawPolygon boundingPolygon

      def g2d = (Graphics2D) g
      Composite originalComposite = g2d.composite
      g2d.composite = makeComposite(0.1F)
      g2d.paint = Color.BLUE
      g2d.fill boundingPolygon
      g2d.composite = originalComposite

      g.color = Color.GREEN
      g.fillOval boundingPolygonLeftX - HBS, boundingPolygonLeftY - HBS, BS, BS
      g.color = Color.YELLOW
      g.fillOval boundingPolygonPrevLeftX - HBS, boundingPolygonPrevLeftY - HBS, BS, BS
      g.color = Color.ORANGE
      g.fillRect boundingPolygonCenterX - HBS, boundingPolygonCenterY - HBS, BS, BS
    }
  }
}
