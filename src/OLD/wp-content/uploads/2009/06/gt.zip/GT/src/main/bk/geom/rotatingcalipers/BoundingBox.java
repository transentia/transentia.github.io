/**
 *
 */
package bk.geom.rotatingcalipers;

/**
 * @author Bart
 *
 */
public class BoundingBox {

    public int minX;
    public int minY;
    public int maxX;
    public int maxY;

    /**
     *
     */
    public BoundingBox() {
      init();
    }

  // BOB
  public void init() {
    this.minX = Integer.MAX_VALUE;
    this.minY = Integer.MAX_VALUE;
    this.maxX = Integer.MIN_VALUE;
    this.maxY = Integer.MIN_VALUE;
  }

  /**
     *
     * @param point
     */
    protected void process(Point point) {
        int x = point.x;
        int y = point.y;
        if(x < minX) minX = x;
        if(x > maxX) maxX = x;
        if(y < minY) minY = y;
        if(y > maxY) maxY = y;
    }

    /**
     *
     */
    public String toString() {
        StringBuilder strb = new StringBuilder();
        strb.append("(minX,minY) = ("+minX+","+minY+")");
        strb.append("(maxX,maxY) = ("+maxX+","+maxY+")");
        return strb.toString();
    }
}
