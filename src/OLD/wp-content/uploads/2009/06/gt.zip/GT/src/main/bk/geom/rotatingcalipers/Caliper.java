/**
 *
 */
package bk.geom.rotatingcalipers;

/**
 * @author Bart
 *
 */
public class Caliper {

    protected Point point1;
    protected Point point2;
    protected Fraction gradient;
    protected Fraction constant;

    /**
     *
     * @param that
     */
    public Caliper(Caliper that) {
        this((Point)that.point1.clone(), (Point)that.point2.clone());
    }

    /**
     *
     * @param a
     * @param b
     */
    public Caliper(Point point1, Point point2) {
        this.point1 = point1;
        this.point2 = point2;
        this.setGradient();
        this.setConstant();
    }


    /**
     *
     * @param that
     * @return the x-intersection of the two calipers.
     * where x-intersect = ((b2 - b1) / (m1 - m2))
     */
    public Fraction xIntersect(Caliper that) {
        if(this.gradient.equals(that.gradient))
            throw new IllegalStateException("Equal gradients!");

        Fraction m1 = this.gradient;
        Fraction m2 = that.gradient;
        Fraction b1 = this.constant;
        Fraction b2 = that.constant;

        return b2.subtract(b1).divide(m1.subtract(m2));
    }

    /**
     *
     * @param x
     * @return the y-intersection of this calipers at point
     * (as a fraction) x.
     * where y-intersect = ((m*x) + b)
     */
    public Fraction yIntersect(Fraction x) {
        Fraction m = this.gradient;
        Fraction b = this.constant;

        return m.multiply(x).add(b);
    }

    /**
     * @param newGradient
     * @return
     */
    public Caliper rotate(Fraction newGradient) {
        int x1 = point1.x, y1 = point1.y,
            x2 = point2.x, y2 = point2.y;

        int n = Math.abs((int)newGradient.num);
        int d = Math.abs((int)newGradient.den);

        if(x1 <= x2 && y1 < y2) {           // caliper I
            return new Caliper(new Point(x2-d, y2-n), new Point(x2, y2));
        } else if(x1 < x2 && y1 >= y2) {    // caliper J
            return new Caliper(new Point(x2-d, y2+n), new Point(x2, y2));
        } else if(x1 >= x2 && y1 > y2) {    // caliper K
            return new Caliper(new Point(x2+d, y2+n), new Point(x2, y2));
        } else {                            // caliper L
            return new Caliper(new Point(x2+d, y2-n), new Point(x2, y2));
        }
    }

    /**
     * Set the line's constant.
     * constant = (-m * x1) + y1
     */
    private void setConstant() {
        final Fraction MINUS_ONE = new Fraction(-1,1);
        Fraction x = new Fraction(point1.x, 1);
        Fraction y = new Fraction(point1.y, 1);
        constant = (((MINUS_ONE.multiply(gradient)).multiply(x)).add(y));
    }

    /**
     * Set the line's gradient.
     * gradient = (y2 - y1) / (x2 - x1)
     */
    private void setGradient() {
        long deltaY = point1.y - point2.y;
        long deltaX = point1.x - point2.x;
        gradient = new Fraction(deltaY, deltaX);
    }

    /**
     * @param that
     * @return the tangent of the angle (theta) between
     *  two lines with gradients m1 and m2:
     *  tan(theta) = (m1 - m2)/(1 + m1*m2)
     */
    public Fraction tangent(Caliper that) {
        final Fraction ONE = new Fraction(1,1);
        Fraction m1 = this.gradient;
        Fraction m2 = that.gradient;

        if(m1.den == 0) {
            return ONE.divide(m2);
        } else if(m2.den == 0) {
            return m1;
        } else {
            return m1.subtract(m2).divide(ONE.add(m1.multiply(m2)));
        }
    }

    /**
     *
     */
    public String toString() {
        StringBuilder strb = new StringBuilder();

        if(gradient.isInfinite())
            return "x = "+point1.x;

        strb.append("y = ");

        if(gradient.equals(new Fraction(1,1)))
            strb.append("x");
        else if(gradient.equals(new Fraction(-1,1)))
            strb.append("-x");
        else if(gradient.doubleValue() != 0.0d)
            strb.append(gradient+"*x");

        if(strb.indexOf("x") == -1)
            strb.append(constant);
        else if(constant.doubleValue() > 0.0d)
            strb.append(" + "+constant);
        else if(constant.doubleValue() < 0.0d)
            strb.append(" - "+constant.multiply(new Fraction(-1,1)));

        return strb.toString();
    }
}
