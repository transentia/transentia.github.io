/**
 *
 */
package bk.geom.rotatingcalipers;

/**
 * @author Bart
 *
 */
public class Fraction implements Cloneable, Comparable<Fraction> {

    public static final Fraction ONE = new Fraction(1,1);
    public static final Fraction MIN_ONE = new Fraction(-1,1);
    public static final Fraction INFINITY = new Fraction(Integer.MAX_VALUE,1);
    protected long num;
    protected long den;

    /**
     *
     * @param n
     * @param d
     */
    public Fraction(long n, long d) {
        if(n != 0 && d != 0) {
            num = (n / (gcd(n,d)));
            den = (d / (gcd(n,d)));
        } else {
            num = n;
            den = d;
        }
        if(den < 0) {
            num = -num;
            den = -den;
        }
    }

    /**
     *
     * @param frac
     * @return
     */
    public static Fraction abs(Fraction frac) {
        long newNum = Math.abs(frac.num);
        long newDen = Math.abs(frac.den);
        return new Fraction(newNum, newDen);
    }

    /**
     * @param that
     * @return 'this' added by 'that'.
     */
    public Fraction add(Fraction that) {
        long newNum = ((this.num * that.den) +
                       (that.num * this.den));
        long newDen = (this.den * that.den);
        return new Fraction(newNum, newDen);
    }

    /**
     *
     */
    public Object clone() {
        try {
            return super.clone();
        } catch(CloneNotSupportedException e) {
            return null;
        }
    }

    /**
     *
     */
    public int compareTo(Fraction that) {
        long thisNum = this.num * that.den;
        long thatNum = that.num * this.den;
        if(thisNum > thatNum)
            return 1;
        else if(thisNum < thatNum)
            return -1;
        else
            return 0;
    }

    /**
     * @param that
     * @return 'this' divided by 'that'.
     */
    public Fraction divide(Fraction that) {
        long newNum = (this.num * that.den);
        long newDen = (this.den * that.num);
        return new Fraction(newNum, newDen);
    }

    /**
     * @return the double value of this fraction.
     */
    public double doubleValue() {
        if(den == 0) return Double.POSITIVE_INFINITY;
        return ((double)num / (double)den);
    }

    /**
     *
     */
    public boolean equals(Object obj) {
        if(!(obj instanceof Fraction)) return false;
        Fraction that = (Fraction)obj;
        if(this.num != that.num) return false;
        if(this.den != that.den) return false;
        return true;
    }

    /**
     * @return the nonnegative greatest common
     * divisor of a and b (Euclid's algorithm).
     */
    private long gcd(long a, long b) {
        long x, y;
        if (a < 0) a = -a;
        if (b < 0) b = -b;
        if (a >= b) { x = a; y = b; }
        else        { x = b; y = a; }
        while (y != 0) {
            long t = x % y;
            x = y;
            y = t;
        }
        return x;
    }

    /**
     * @return
     */
    public boolean isInfinite() {
        return den == 0 || this.equals(Fraction.INFINITY);
    }

    /**
     * @return
     */
    public boolean isPositive() {
        return this.doubleValue() > 0.0d && !this.isInfinite();
    }

    /**
     * @param that
     * @return 'this' multiplied by 'that'.
     */
    public Fraction multiply(Fraction that) {
        long newNum = (this.num * that.num);
        long newDen = (this.den * that.den);
        return new Fraction(newNum, newDen);
    }

    /**
     * @param that
     * @return 'this' subtracted from 'that'.
     */
    public Fraction subtract(Fraction that) {
        long newNum = ((this.num * that.den) -
                       (that.num * this.den));
        long newDen = (this.den * that.den);
        return new Fraction(newNum, newDen);
    }

    /**
     *
     */
    public String toString() {
        if(this.isInfinite()) return "INF";
        if(den == 1 || num == 0) return String.valueOf(num);
        return "("+num+"/"+den+")";
    }
}
