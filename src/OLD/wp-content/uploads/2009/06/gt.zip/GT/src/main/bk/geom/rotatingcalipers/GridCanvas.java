/**
 *
 */
package bk.geom.rotatingcalipers;

import java.awt.Color;
import java.awt.Canvas;
import java.awt.Graphics;

/**
 * @author Bart
 *
 */
public class GridCanvas extends Canvas {

    private static final long serialVersionUID = 1L;
    protected Polygon polygon;
    protected RotatingCalipers rotator;
    protected int width;
    protected int height;
    protected Rectangle colorRect;

    /**
     *
     * @param parent
     */
    public GridCanvas(int w, int h) {
        super();
        width = w;
        height = h;
        this.setSize(width, height);
        polygon = new Polygon();
        colorRect = null;
        this.setBackground(Color.WHITE);
    }

    /**
     *
     * @param x
     * @param y
     * @param correctionNeeded
     */
    public void addPoint(int x, int y, boolean correctionNeeded) {
        if(correctionNeeded) {
            x = x-(width/2);
            y = (height/2)-y;
        }
        polygon.addPoint(new Point(x,y));
        colorRect = null;
        if(!polygon.allPointsCollinear() && polygon.points.size() >= 3) {
            rotator = new RotatingCalipers(polygon);
        }
        repaint();
    }

    /**
     *
     * @return
     */
    public int numberOfRectangles() {
        if(rotator == null) return 0;
        return rotator.rectangles.size();
    }

    /**
     *
     */
    public void paint(Graphics g) {
        final int N = 6;
        final int X_CORR = width/2;
        final int Y_CORR = height/2;

        g.setColor(Color.LIGHT_GRAY);
        g.drawLine(X_CORR, 0, X_CORR, Y_CORR*2); // y axis
        g.drawLine(0, Y_CORR, X_CORR*2, Y_CORR); // x axis

        if(!polygon.allPointsCollinear() && polygon.points.size() >= 3) {

            Polygon hull = polygon.getConvexHull();
            g.setColor(Color.RED);
            for(int i = 0; i < hull.points.size()-1; i++) {
                Point p_0 = hull.points.get(i);
                Point p_1 = hull.points.get(i+1);
                g.drawLine(p_0.x+X_CORR, Y_CORR-p_0.y, p_1.x+X_CORR, Y_CORR-p_1.y);
            }

            if(colorRect != null) {
                g.setColor(Color.GREEN);
                double[] xs = colorRect.xPoints;
                double[] ys = colorRect.yPoints;
                for(int j = 0; j < xs.length-1; j++) {
                    int x_0 = (int)xs[j];
                    int y_0 = (int)ys[j];
                    int x_1 = (int)xs[j+1];
                    int y_1 = (int)ys[j+1];
                    g.drawLine(x_0+X_CORR, Y_CORR-y_0, x_1+X_CORR, Y_CORR-y_1);
                }
            }
        }

        g.setColor(Color.BLUE);
        for(int i = 0; i < polygon.points.size(); i++) {
            Point p = polygon.points.get(i);
            g.fillOval(p.x-(N/2)+X_CORR, Y_CORR-p.y-(N/2), N, N);
        }
    }

    /**
     *
     */
    public void reset() {
        polygon = new Polygon();
        rotator = null;
        colorRect = null;
        repaint();
    }

    /**
     *
     * @param r
     */
    public void setRectangle(Rectangle r) {
        colorRect = r;
    }
}
