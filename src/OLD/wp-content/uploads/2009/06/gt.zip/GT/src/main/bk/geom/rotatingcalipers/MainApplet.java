/**
 *
 */
package bk.geom.rotatingcalipers;

import javax.swing.*;
import java.applet.Applet;
import java.awt.event.*;
import java.util.Scanner;

/**
 * @author Bart
 *
 */
public class MainApplet extends Applet
                        implements MouseListener,
                                   ActionListener,
                                   KeyListener,
                                   MouseMotionListener {

    private static final long serialVersionUID = 1L;
    protected bk.geom.rotatingcalipers.GridCanvas grid;
    protected JButton btnReset;
    protected JButton btnAdd;
    protected JList lstRectangles;
    protected DefaultListModel mdlRectangles;
    protected JLabel lblRectangle;
    protected JTextArea txtRectangle;
    protected JTextArea txtAllPoints;
    protected JTextArea txtAddPoints;
    protected JLabel lblCoordinates;

    /**
     *
     */
    public MainApplet() {
        super();
        this.setSize(878, 595);
        this.setLayout(null);
        addComponents();
        this.setVisible(true);
    }

    /**
     *
     */
    public void actionPerformed(ActionEvent ae) {
        Object source = ae.getSource();

        if(source == btnReset) {
            grid.reset();
            mdlRectangles.clear();
            lblRectangle.setText("");
            txtRectangle.setText("");
            lblCoordinates.setText("");
            txtAllPoints.setText("");
            txtAddPoints.setText("");
        }

        if(source == btnAdd) {

            Scanner scan = new Scanner(txtAddPoints.getText());
            StringBuilder errors = new StringBuilder();
            while(scan.hasNextLine()) {
                String line = scan.nextLine().trim();
                String line2 = line.replaceAll("\\(", "");
                line2 = line2.replaceAll("\\)", "");
                line2 = line2.replaceAll(" +", "");
                String[] array = line2.split(",");
                try {
                    int x = Integer.parseInt(array[0]);
                    int y = Integer.parseInt(array[1]);
                    grid.addPoint(x, y, false);
                } catch(Exception e) {
                    errors.append(line+"\n");
                }
            }
            if(errors.length() > 0) {
                txtRectangle.setText("There were problems adding the following points:"+
                        "\n\n"+errors.toString());
            }
            if(grid != null) grid.repaint();
            txtAddPoints.setText("");
            this.updateTxtAreas();
        }
    }

    /**
     *
     */
    private void addComponents() {
        grid = new GridCanvas(500, 500);
        grid.setBounds(360, 40, 500, 500);
        grid.addMouseListener(this);
        grid.addMouseMotionListener(this);
        this.add(grid);

        lblCoordinates = new JLabel();
        lblCoordinates.setBounds(795, 545, 100, 20);
        lblCoordinates.setAlignmentX(JComponent.RIGHT_ALIGNMENT);
        this.add(lblCoordinates);

        btnReset = new JButton("reset");
        btnReset.addActionListener(this);
        btnReset.setBounds(780, 10, 80, 20);
        this.add(btnReset);

        JLabel lblRectangles = new JLabel("Rectangles:");
        lblRectangles.setBounds(10, 20, 100, 20);
        this.add(lblRectangles);

        mdlRectangles = new DefaultListModel();
        lstRectangles = new JList(mdlRectangles);
        lstRectangles.addMouseListener(this);
        lstRectangles.addKeyListener(this);
        JScrollPane scrllLst = new JScrollPane(lstRectangles);
        scrllLst.setBounds(10, 40, 100, 200);
        this.add(scrllLst);

        JLabel lblAllPoints = new JLabel("Added points:");
        lblAllPoints.setBounds(120, 20, 100, 20);
        this.add(lblAllPoints);

        txtAllPoints = new JTextArea();
        txtAllPoints.setEditable(false);
        JScrollPane scrllAllPoints = new JScrollPane(txtAllPoints);
        scrllAllPoints.setBounds(120, 40, 100, 200);
        this.add(scrllAllPoints);

        JLabel lblAddPoints = new JLabel("Points to add:");
        lblAddPoints.setBounds(230, 20, 100, 20);
        this.add(lblAddPoints);

        txtAddPoints = new JTextArea();
        JScrollPane scrllAddPoints = new JScrollPane(txtAddPoints);
        scrllAddPoints.setBounds(230, 40, 100, 175);
        this.add(scrllAddPoints);

        btnAdd = new JButton("add points");
        btnAdd.addActionListener(this);
        btnAdd.setBounds(231, 220, 100, 18);
        this.add(btnAdd);

        lblRectangle = new JLabel("");
        lblRectangle.setBounds(10, 250, 320, 20);
        this.add(lblRectangle);

        txtRectangle = new JTextArea();
        txtRectangle.setEditable(false);
        JScrollPane scrllTxt = new JScrollPane(txtRectangle);
        scrllTxt.setBounds(10, 300, 320, 240);
        this.add(scrllTxt);
    }

    public void keyReleased(KeyEvent ke) {
        Object source = ke.getSource();

        if(source == lstRectangles) {
            int selected = lstRectangles.getSelectedIndex();
            Rectangle rect = grid.rotator.rectangles.get(selected);
            grid.setRectangle(rect);
            txtRectangle.setText(rect.toString());
            grid.repaint();
        }
    }

    /**
     *
     */
    public void mouseMoved(MouseEvent me) {
        Object source = me.getSource();

        if(source == grid) {
            int x = me.getX()-(grid.width/2);
            int y = (grid.height/2)-me.getY();
            lblCoordinates.setText("("+x+","+y+")");
        }
    }

    /**
     *
     */
    public void mousePressed(MouseEvent me) {
        Object source = me.getSource();

        if(source == lstRectangles) {
            int selected = lstRectangles.getSelectedIndex();
            if(selected == -1) return;
            Rectangle rect = grid.rotator.rectangles.get(selected);
            grid.setRectangle(rect);
            txtRectangle.setText(rect.toString());
            grid.repaint();
        }

        if(source == grid) {
            grid.addPoint(me.getX(), me.getY(), true);
            txtRectangle.setText("");
            this.updateTxtAreas();
        }
    }

    public void mouseClicked(MouseEvent me) {}
    public void mouseEntered(MouseEvent me) {}
    public void mouseExited(MouseEvent me) {}
    public void mouseReleased(MouseEvent me) {}
    public void keyPressed(KeyEvent ke) {}
    public void keyTyped(KeyEvent ke) {}
    public void mouseDragged(MouseEvent me) {}

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new bk.geom.rotatingcalipers.MainFrame();
            }
        });
    }

    /**
     *
     */
    private void updateTxtAreas() {

        Polygon p = grid.polygon;
        StringBuilder strb = new StringBuilder();
        for(int i = 0; i < p.points.size(); i++) {
            strb.append(p.points.get(i));
            strb.append('\n');
        }
        txtAllPoints.setText(strb.toString());

        int numRectangles = grid.numberOfRectangles();
        if(numRectangles == 0) return;
        mdlRectangles.clear();
        for(int i = 0; i < numRectangles; i++) {
            mdlRectangles.add(i, "Rectangle "+(i+1));
        }
        int minimum = grid.rotator.getIndexSmallestRectangle();
        lblRectangle.setText("Minimum area: Rectangle "+(minimum+1));
    }
}

