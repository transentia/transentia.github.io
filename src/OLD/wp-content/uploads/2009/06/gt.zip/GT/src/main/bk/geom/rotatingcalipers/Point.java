/**
 *
 */
package bk.geom.rotatingcalipers;

/**
 * @author Bart
 *
 */
public class Point implements Cloneable {

    public int x;
    public int y;

    /**
     * Protect the empty c'tor from being used.
     */
    private Point() {}

    /**
     * Create a point representing a location in
     * (x,y) coordinate space.
     * @param x the x-coordinate.
     * @param y the y-coordinate.
     */
    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * @param that
     * @return the angle between 'this' and
     * 'that' point seen from the x-axis.
     */
     public double angle(Point that) {
         double dX = (that.x - this.x);
         double dY = (that.y - this.y);
         double t = 0.0d;

         if (dX == 0.0) {
             if(dY == 0.0)      t = 0.0;
             else if(dY > 0.0)  t = Math.PI/2.0;
             else               t = Math.PI*3.0/2.0;
         } else if(dY == 0.0) {
             if(dX > 0.0)       t = 0.0;
             else               t = Math.PI;
         } else {
             if(dX < 0.0)       t = Math.atan(dY/dX)+Math.PI;
             else if(dY < 0.0)  t = Math.atan(dY/dX)+(2*Math.PI);
             else               t = Math.atan(dY/dX);
         }
         return t*180/Math.PI;
     }

    /**
     *
     */
    public Object clone() {
        try {
            return super.clone();
        } catch(CloneNotSupportedException e) {
            return null;
        }
    }

    /**
     * @param that
     * @return the absolute distance between
     * 'this' and 'that' point.
     */
    public double distance(Point that) {
        double dX = Math.abs(this.x - that.x);
        double dY = Math.abs(this.y - that.y);
        return Math.sqrt((dX*dX)+(dY*dY));
    }

    /**
     *
     */
    public boolean equals(Object obj) {
        if(!(obj instanceof Point)) return false;
        Point that = (Point)obj;
        return (this.x == that.x && this.y == that.y);
    }

     /**
      *
      */
     public int hashCode() {
         return x^(y*31);
     }

     /**
      *
      */
     public String toString() {
         return "("+x+","+y+")";
     }
}
