/**
 *
 */
package bk.geom.rotatingcalipers;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * @author Bart
 *
 */
public class Polygon {

    public List<Point> points;
    protected BoundingBox boundingBox;

    // BOB
    public int size() {
      return points.size();
    }

  public void removePoint(Point p) {
    points.remove(p);
  }

  public void clear() {
    points.clear();
    boundingBox.init();
  }

  public BoundingBox getBoundingBox() {
    return boundingBox;
  }
    /**
     * Creates a new Polygon with 0 points.
     */
    public Polygon() {
        this.points = new ArrayList<Point>();
        this.boundingBox = new BoundingBox();
    }

    /**
     * Creates a new Polygon with an initial list of points.
     * A shallow copy of the points from 'pts' are made.
     * @param pts
     */
    public Polygon(List<Point> pts) {
        this();
        for(int i = 0; i < pts.size(); i++) {
            Point temp = (Point)pts.get(i).clone();
            this.addPoint(temp, true);
        }
    }

    /**
     *
     * @param point
     */
    public void addPoint(Point point) {
        this.addPoint(point, false);
    }

    /**
     *
     * @param point
     * @param duplicates
     */
    public void addPoint(Point point, boolean duplicates) {
        if(!duplicates && points.contains(point)) return;
        boundingBox.process(point);
        points.add(point);
    }

    /**
     * @return true iff all point are collinear.
     */
    public boolean allPointsCollinear() {
        if(points.size() <= 2) return false;
        double theta = points.get(0).angle(points.get(1));
        for(int i = 2; i < points.size(); i++) {
            double temp = points.get(i-1).angle(points.get(i));
            if(temp != theta && Math.abs(temp-theta) != 180.0) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param b point b
     * @param c point c
     * @param f point f
     * @return true iff the three points form a right turn.
     */
    private boolean formRightTurn(Point b, Point c, Point f) {
        return ( ((b.x - c.x) * (c.y - f.y)) -
                 ((c.x - f.x) * (b.y - c.y)) <= 0);
    }

    /**
     * This is an implementation of the 3-coins algorithm
     * (a.k.a. Graham-scan) which was developed independently
     * by Graham and Sklansky in 1972, to find a convex hull
     * from a set of polygon.
     * @return the convex hull of this polygon.
     */
    public Polygon getConvexHull() {
        if(points.size() < 3)
            throw new IllegalStateException("Polygon must have more than 2 points!");
        if(this.allPointsCollinear())
            throw new IllegalStateException("All points are collinear!");

        List<Point> sorted = this.getSortedPoints();
        Stack<Point> stack = new Stack<Point>();
        sorted.add(sorted.get(0));                   // Add the first point to the end as well.

        Point back = sorted.get(0);                  // The first three points
        Point center = sorted.get(1);                // will always form a right
        Point front = sorted.get(2);                 // turn.
        stack.push(back);
        stack.push(center);                          // Push the first three points
        stack.push(front);                           // on the stack.

        for(int i = 3; i < sorted.size(); i++) {
            if(formRightTurn(back, center, front)) { // The last 3 points form a right turn
                back = center;                       //  - back++
                center = front;                      //  - center++
                front = sorted.get(i);               //  - front -> next from sorted list
                stack.push(front);                   //  - push front
            } else {                                 // The last 3 points form a left turn
                front = stack.pop();                 //  - keep the current front
                stack.pop();                         //  - pop the current center
                center = stack.pop();                //  - center--
                back = stack.pop();                  //  - back--
                stack.push(back);                    //  - push back
                stack.push(center);                  //  - push center
                stack.push(front);                   //  - push front
                i--;                                 //    Decrease counter for nothing
            }                                        //    is taken from the list.
        }
        return new Polygon(stack);                   // Return convex hull
    }

    /**
     * @return the point with the smallest Y-value. In case of a tie, the
     * point with the smallest X-value is selected.
     */
    public Point getMostTopLeft() {
        Point bottom = points.get(0);

        for(int i = 1; i < points.size(); i++) {
            Point temp = points.get(i);
            if(temp.y < bottom.y || (temp.y == bottom.y && temp.x < bottom.x)) {
                bottom = temp;
            }
        }
        return bottom;
    }

    /**
     * @param p_0
     * @param unsorted
     * @return the next point with the biggest angle still
     * in the unsorted list from 'p_0'. In case of a tie, the
     * points closest to p_0 is deleted, since that point is
     * not extremal.
     */
    private Point getNextBiggestAngle(Point p_0, List<Point> unsorted) {
        Point point = unsorted.get(0);
        double angle = p_0.angle(point);

        if(unsorted.size() > 1) {
            for(int i = 1; i < unsorted.size(); i++) {
                Point tempPoint = unsorted.get(i);
                double tempAngle = p_0.angle(tempPoint);

                if(tempAngle > angle) {
                    point = tempPoint;
                    angle = tempAngle;
                } else if(tempAngle == angle) {
                    if(p_0.distance(point) > p_0.distance(tempPoint)) {
                        unsorted.remove(tempPoint);
                    } else {
                        unsorted.remove(point);
                        point = tempPoint;
                    }
                }
            }
        }
        return point;
     }

    /**
     * @return Sorting radially about the lowest point p_0: For
     * each point p_i, we compute the angle that the line
     * segment [p_0, p_i] makes with the (horizontal) positive
     * x-axis. Angles are sorted from largest to smallest.
     */
    public List<Point> getSortedPoints() {
        List<Point> unsorted = new ArrayList<Point>(points);
        List<Point> sorted = new ArrayList<Point>();

        Point p_0 = this.getMostTopLeft();
        unsorted.remove(p_0);
        sorted.add((Point)p_0.clone());

        while(unsorted.size() > 0) {
            Point p_i = this.getNextBiggestAngle(p_0, unsorted);
            unsorted.remove(p_i);
            sorted.add((Point)p_i.clone());
        }
        return sorted;
    }

    /**
     *
     */
    public String toString() {
        if(this.points.size() == 0) return "No Points";
        StringBuilder strb = new StringBuilder();
        strb.append(this.points.get(0));
        for(int i = 1; i < this.points.size(); i++) {
            strb.append(" --> ");
            strb.append(this.points.get(i));
        }
        strb.append(boundingBox);
        return strb.toString();
    }
}
