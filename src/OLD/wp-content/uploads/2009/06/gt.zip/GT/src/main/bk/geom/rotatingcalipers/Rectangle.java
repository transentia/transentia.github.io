/**
 *
 */
package bk.geom.rotatingcalipers;

import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * @author Bart
 *
 */
public class Rectangle implements Comparable<Rectangle> {

    protected bk.geom.rotatingcalipers.Caliper[] calipers;
    public double[] xPoints;
    public double[] yPoints;

    /**
     *
     */
    private Rectangle() {
        xPoints = new double[5];
        yPoints = new double[5];
    }

    /**
     *
     * @param box
     * @param i
     * @param j
     * @param k
     * @param l
     */
    public Rectangle(BoundingBox box, Caliper i, Caliper j, Caliper k, Caliper l) {
        this();
        calipers = new Caliper[]{i, j, k, l};

        xPoints[0] = (double)box.minX;
        yPoints[0] = (double)box.minY;

        xPoints[1] = (double)box.minX;
        yPoints[1] = (double)box.maxY;

        xPoints[2] = (double)box.maxX;
        yPoints[2] = (double)box.maxY;

        xPoints[3] = (double)box.maxX;
        yPoints[3] = (double)box.minY;

        xPoints[4] = xPoints[0];
        yPoints[4] = yPoints[0];
    }

    /**
     *
     * @param i
     * @param j
     * @param k
     * @param l
     */
    public Rectangle(Caliper i, Caliper j, Caliper k, Caliper l) {
        this();
        calipers = new Caliper[]{i, j, k, l};
        this.calculatePoints(i, j, k, l);
    }

    /**
     *
     * @return
     */
    public double area() {
        double dX_1 = xPoints[0] - xPoints[1];
        double dY_1 = yPoints[0] - yPoints[1];
        double dX_2 = xPoints[1] - xPoints[2];
        double dY_2 = yPoints[1] - yPoints[2];
        double l_1 = Math.sqrt((dX_1*dX_1) + (dY_1*dY_1));
        double l_2 = Math.sqrt((dX_2*dX_2) + (dY_2*dY_2));
        return (l_1 * l_2);
    }

    /**
     *
     * @param i
     * @param j
     * @param k
     * @param l
     */
    private void calculatePoints(Caliper i, Caliper j, Caliper k, Caliper l) {

        xPoints[0] = i.xIntersect(j).doubleValue();
        yPoints[0] = i.yIntersect(i.xIntersect(j)).doubleValue();

        xPoints[1] = j.xIntersect(k).doubleValue();
        yPoints[1] = j.yIntersect(j.xIntersect(k)).doubleValue();

        xPoints[2] = k.xIntersect(l).doubleValue();
        yPoints[2] = k.yIntersect(k.xIntersect(l)).doubleValue();

        xPoints[3] = l.xIntersect(i).doubleValue();
        yPoints[3] = l.yIntersect(l.xIntersect(i)).doubleValue();

        xPoints[4] = i.xIntersect(j).doubleValue();
        yPoints[4] = i.yIntersect(i.xIntersect(j)).doubleValue();
    }

    /**
     *
     * @param that
     * @return
     */
    public int compareTo(Rectangle that) {
        double diff = this.area() - that.area();
        if(diff < 0.0)      return -1;
        else if(diff > 0.0) return 1;
        else                return 0;
    }

    /**
     *
     */
    public String toString() {
        NumberFormat f = new DecimalFormat("0.00");
        StringBuilder strb = new StringBuilder();
        strb.append("Area ~= "+f.format(this.area())+"\n\n");
        strb.append("Corner points:\n\n");
        strb.append("     ("+f.format(xPoints[1])+", "+f.format(yPoints[1])+")");
        strb.append("     ("+f.format(xPoints[2])+", "+f.format(yPoints[2])+")\n");
        strb.append("     ("+f.format(xPoints[0])+", "+f.format(yPoints[0])+")");
        strb.append("     ("+f.format(xPoints[3])+", "+f.format(yPoints[3])+")\n");
        strb.append("\nCalipers:\n");
        strb.append("\n     "+calipers[0]);
        strb.append("\n     "+calipers[1]);
        strb.append("\n     "+calipers[2]);
        strb.append("\n     "+calipers[3]);
        return strb.toString();
    }
}
