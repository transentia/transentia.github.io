/**
 *
 */
package bk.geom.rotatingcalipers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Rotating Calipers Algorithm:
 *
 * [1] Find the vertices with the minimum and maximum x an y coordinates.
 *     These vertices (points) will be denoted by {pI, pJ, pK, pL}
 * [2] Construct calL and calJ as the first set of 'calipers' parallel to
 *     the x-axis, and calI and calK as the second set of 'calipers'
 *     parallel to the y-axis.
 * [3] Create for every caliper a nextCaliper based on the next point in
 *     the convex hull and calculate the tangent of caliper_N and it's
 *     nextCaliper_N.
 * [4] Get the smallest positive tangent and rotate every caliper with
 *     that gradient.
 * [5] Repeat step 3 and 4 untill the calipers have turned more then
 *     90 degrees
 *
 * @author Bart
 *
 */
public class RotatingCalipers {

    private final int i = 0, j = 1, k = 2, l = 3;
    protected Polygon hull;
    private Point pI, pJ, pK, pL;
    private Caliper calI, calJ, calK, calL;
    public List<Rectangle> rectangles;

    /**
     *
     * @param polygon
     */
    public RotatingCalipers(Polygon polygon) {
        hull = polygon.getConvexHull();
        rectangles = new ArrayList<Rectangle>();
        this.initialize();
        this.rotateCalipers();
    }

    /**
     *
     * @param tangents
     * @return
     */
    private Fraction getMinPositiveTangent(Fraction[] tangents) {
        Fraction min = Fraction.INFINITY;
        for(int i = 0; i < tangents.length; i++) {
            Fraction temp = tangents[i];
            if(temp.isPositive() && temp.compareTo(min) < 0) {
                min = temp;
            }
        }
        return min;
    }

    /**
     *
     * @return
     */
    public int getIndexSmallestRectangle() {
        List<Rectangle> temp = new ArrayList<Rectangle>(rectangles);
        Collections.sort(temp);
        Rectangle smallest = temp.get(0);
        return rectangles.indexOf(smallest);
    }

    /**
     *
     * @param i
     * @param j
     * @param k
     * @param l
     * @return
     */
    private Fraction[] getTangents(Caliper ci, Caliper cj, Caliper ck, Caliper cl) {
        Fraction[] tangents = new Fraction[4];
        tangents[i] = ci.tangent(this.nextCaliper(ci));
        tangents[j] = cj.tangent(this.nextCaliper(cj));
        tangents[k] = ck.tangent(this.nextCaliper(ck));
        tangents[l] = cl.tangent(this.nextCaliper(cl));
        return tangents;
    }

    /**
     * [1] Find the vertices with the minimum and maximum x an y coordinates.
     *     These vertices (points) will be denoted by {pI, pJ, pK, pL}
     * [2] Construct calL and calJ as the first set of 'calipers' parallel to
     *     the x-axis, and calI and calK as the second set of 'calipers'
     *     parallel to the y-axis.
     */
    private void initialize() {
        pI = pJ = pK = pL = hull.points.get(0);

        for(int i = 1; i < hull.points.size(); i++) {
            Point p = hull.points.get(i);
            if(p.x < pI.x || (p.x == pI.x && p.y > pI.y)) pI = p;
            if(p.y > pJ.y || (p.y == pJ.y && p.x > pJ.x)) pJ = p;
            if(p.x > pK.x || (p.x == pK.x && p.y < pK.y)) pK = p;
            if(p.y < pL.y || (p.y == pL.y && p.x < pL.x)) pL = p;
        }
        calI = new Caliper(new Point((int)pI.x, pI.y-1), pI);
        calJ = new Caliper(new Point((int)pJ.x-1, pJ.y), pJ);
        calK = new Caliper(new Point((int)pK.x, pK.y+1), pK);
        calL = new Caliper(new Point((int)pL.x+1, pL.y), pL);
    }

    /**
     *
     * @param current
     * @return
     */
    private Caliper nextCaliper(Caliper current) {
        int indexPoint2 = hull.points.indexOf(current.point2);
        Point next = hull.points.get(indexPoint2+1);
        return new Caliper((Point)current.point2.clone(), (Point)next.clone());
    }

    /**
     * [3] Create for every caliper a nextCaliper based on the next point in
     *     the convex hull and calculate the tangent of caliper_N and it's
     *     nextCaliper_N.
     * [4] Get the smallest positive tangent and rotate every caliper with
     *     that gradient.
     * [5] Repeat step 3 and 4 untill the calipers have turned more then
     *     90 degrees
     */
    private void rotateCalipers() {

        rectangles.add(new Rectangle(hull.boundingBox, calI, calJ, calK, calL));
        boolean rotatedI, rotatedJ, rotatedK, rotatedL;

        while(true) {
            Fraction[] tangents = this.getTangents(calI, calJ, calK, calL);
            Fraction minTan = this.getMinPositiveTangent(tangents);
            Fraction nextGradIK, nextGradJL;
            rotatedI = rotatedJ = rotatedK = rotatedL = false;
            /*
            System.out.println("\ncalI >>> "+calI+"\t\ttan = "+tangents[0]);
            System.out.println("calJ >>> "+calJ+"\t\ttan = "+tangents[1]);
            System.out.println("calK >>> "+calK+"\t\ttan = "+tangents[2]);
            System.out.println("calL >>> "+calL+"\t\ttan = "+tangents[3]);
            */
            if(tangents[i].equals(minTan)) {
                calI = this.nextCaliper(calI);
                nextGradIK = calI.gradient;
                nextGradJL = Fraction.ONE.divide(nextGradIK);
                rotatedI = true;
            } else if(tangents[j].equals(minTan)) {
                calJ = this.nextCaliper(calJ);
                nextGradJL = calJ.gradient;
                nextGradIK = Fraction.MIN_ONE.divide(nextGradJL);
                rotatedJ = true;
            } else if(tangents[k].equals(minTan)) {
                calK = this.nextCaliper(calK);
                nextGradIK = calK.gradient;
                nextGradJL = Fraction.ONE.divide(nextGradIK);
                rotatedK = true;
            } else {
                calL = this.nextCaliper(calL);
                nextGradJL = calL.gradient;
                nextGradIK = Fraction.MIN_ONE.divide(nextGradJL);
                rotatedL = true;
            }
            /*
            System.out.println("\tnext calI >>> "+calI.rotate(nextGradIK));
            System.out.println("\tnext calJ >>> "+calJ.rotate(nextGradJL));
            System.out.println("\tnext calK >>> "+calK.rotate(nextGradIK));
            System.out.println("\tnext calL >>> "+calL.rotate(nextGradJL));
            if(rotatedI) System.out.println("* I *");
            if(rotatedJ) System.out.println("* J *");
            if(rotatedK) System.out.println("* K *");
            if(rotatedL) System.out.println("* L *");
            System.out.println("-------------------------------------------------------------------");
            */
            if(!rotatedI) calI = calI.rotate(nextGradIK);
            if(!rotatedJ) calJ = calJ.rotate(nextGradJL);
            if(!rotatedK) calK = calK.rotate(nextGradIK);
            if(!rotatedL) calL = calL.rotate(nextGradJL);

            if(!calI.gradient.isPositive() || !calK.gradient.isPositive() ||
                calJ.gradient.isPositive() || calL.gradient.isPositive()) {
                break;
            }
            rectangles.add(new Rectangle(calI, calJ, calK, calL));
        }
    }
}
