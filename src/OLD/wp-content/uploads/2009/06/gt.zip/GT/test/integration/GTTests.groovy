class GTTests extends GroovyTestCase {

    void testSomething() {

    }
}
