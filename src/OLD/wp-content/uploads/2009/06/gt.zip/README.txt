To run:

Open a command shell in the GT directory below where this README is, then:

griffon run-app

To use:

Open the 3squares.jpg file (in the same folder as this README).
Click on each corner of the one of the angled post-it notes to isolate it.
Press the Extract button.
The resulting extracted, rotated image will appear in the right-hand panel. It can be saved as a PNG, if you so desire.

The top-left post-it note sub-image will require an additional 90-degree clockwise rotation after auto-extraction; this can be done using the second-from-left tool button at the bottom-right of the window.

Enjoy.

Some weasel words:

I make NO (none, nil, nada, zip, zero) guarantees that this app is fit for anything. Anything at all. It has bugs (all software has).... It may destroy your data, your computer and your love life, who knows. Your use is dependent on your own discretion. YOu get the quality that you paid for. You have been warned.

It could be better. Feel free to hack it as you feel fit. If you do hack it, I'd love to know what you do with it. I'd love some kind of (nice ;-)) attribution. I'd love to be able to link to a blog entry or some such...

I don't charge for the code. If you make a small profit from the code, good luck to you! If you make a motza from it, gimme ;-)

I have no idea as to the licensing surrounding the Rotating Calipers code. I am assuming that the author put it out there to be used. He may have other ideas, who knows.

Some of the icons used come from famfamfam.com.
See: http://www.famfamfam.com/lab/icons/silk/

12:32 PM 3/06/2009

