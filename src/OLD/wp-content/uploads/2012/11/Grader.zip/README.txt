To run this you will need:

java 1.6; I use jdk1.6.0_30
gradle 1.0; I use gradle-1.0-milestone-6

To execute on Win7:

gradle clean
gradle check
gradle cobertura
gradle gmetrics

HTML reports are created under build/reports.

Thanks for Mrhaki for the basic GMetrics XSLT report transformation, see http://mrhaki.blogspot.com/2011/01/groovy-goodness-create-gmetrics-report.html
