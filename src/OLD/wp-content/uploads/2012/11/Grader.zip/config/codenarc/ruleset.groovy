ruleset {

    description 'Grader CodeNarc RuleSet'

		/*
    ruleset( "http://codenarc.sourceforge.net/StarterRuleSet-AllRulesByCategory.groovy.txt" ) {
		*/
    ruleset("config/codenarc/StarterRuleSet-AllRulesByCategory.groovy.txt" ) {

        DuplicateNumberLiteral   ( enabled : false )
        DuplicateStringLiteral   ( enabled : false )
        BracesForClass           ( enabled : false )
        BracesForMethod          ( enabled : false )
        IfStatementBraces        ( enabled : false )
        BracesForIfElse          ( enabled : false )
        BracesForForLoop         ( enabled : false )
        BracesForTryCatchFinally ( enabled : false )
        JavaIoPackageAccess      ( enabled : false )
        ThrowRuntimeException    ( enabled : false )

        //AbcComplexity            ( maxMethodComplexity : 70  )
        //LineLength               ( length              : 180 )
        //MethodName               ( regex               : /[a-z][\w\s'\(\)]*/ ) // Spock method names
    }
}
