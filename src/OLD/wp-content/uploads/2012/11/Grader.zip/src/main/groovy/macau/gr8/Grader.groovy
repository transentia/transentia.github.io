package macau.gr8

class Grader {
    def expectedAnswers
    def graderFileReader

    def grade(String s) {
        def candidateAnswers = graderFileReader.readGradesListFromFile(s)

        grade(candidateAnswers)
    }

    def grade(List candidateAnswers) {
        if (expectedAnswers?.size() != candidateAnswers?.size())
          -1.0
        else {
            def count = 0
            expectedAnswers.eachWithIndex {o,index ->
                if (o == candidateAnswers[index]) count ++
            }
            
        count / expectedAnswers.size()
        }
    }
}