package macau.gr8;

class GraderFileReader {
    def readGradesListFromFile(name) {
        def f = new File(name)
        if (!f.exists())
          throw new Exception("File $name does not exist.")
        def txt = f.text
        txt?.split(',') as List
    }
}
