package macau.gr8;

// requires: hamcrest-core-1.2.jar
//           spock-core-0.5-groovy-1.7
//           groovy-1.7.10

import spock.lang.Specification
import static spock.util.matcher.HamcrestMatchers.closeTo
import static spock.util.matcher.HamcrestSupport.that
import spock.lang.Unroll
import spock.lang.AutoCleanup
import org.apache.poi.ss.usermodel.WorkbookFactory

public class GraderExcelSpecification extends Specification {
    @AutoCleanup(quiet = true)
    def grader = new Grader(expectedAnswers: ['a', 'b', 'c'])

    @Unroll("#iterationCount: grade for #paper is #res")
    def "Grader with papers from Excel"() {
        expect: "Grade an individual paper"
            that grader.grade(paper), closeTo(res, 0.01D)

        where: "With the following papers"
            [paper, res] << new ExcelHelper(excelFilename: /rsrc\test.xlsx/).rows()
    }
}

class ExcelHelper {
    def excelFilename

    def rows() {
        def workBook = WorkbookFactory.create(new FileInputStream(excelFilename))
        def sheet = workBook.getSheetAt(0)
        sheet.rowIterator().collect([]) { row ->
            def firstCell = row.getCell(row.firstCellNum)
            def paper
            def res
            if ("null" == firstCell?.stringCellValue)
                (paper, res) = [null, -1.0D]
            else {
                paper = []
                (row.firstCellNum + 1..<row.lastCellNum - 1).each {
                    def cell = row.getCell(it)
                    if (cell)
                        paper << cell.stringCellValue
                }
                res = row.getCell(row.lastCellNum - 1).numericCellValue
            }
            [paper, res]
        }
    }
}
