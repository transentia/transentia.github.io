package macau.gr8;

import spock.lang.AutoCleanup
import spock.lang.Specification

class GraderMockedSpecification extends Specification {
    @AutoCleanup(quiet = true)
    def grader = new Grader(expectedAnswers: ['a','b','c'])

    def "Given a mock file"() {
        setup: "Establish the grader with a mocked GraderFileReader"
          def graderFileReader = Mock(GraderFileReader)
          grader.graderFileReader = graderFileReader
          1 * graderFileReader.readGradesListFromFile(_) >> ['a','b','c']
          0 * _._

        when: "Read a paper's answers from a given file"
         def res  = grader.grade('100pct.txt')
        
        then: "Ensure expected behaviour"
          res == 1.0D
    }
}
