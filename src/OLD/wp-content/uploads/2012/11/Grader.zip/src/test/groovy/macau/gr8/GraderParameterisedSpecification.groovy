package macau.gr8;

import spock.lang.Specification
import static spock.util.matcher.HamcrestMatchers.closeTo
import static spock.util.matcher.HamcrestSupport.that
import spock.lang.Unroll
import spock.lang.AutoCleanup

public class GraderParameterisedSpecification extends Specification {
    @AutoCleanup(quiet = true)
    def grader = new Grader(expectedAnswers: ['a', 'b', 'c'])

    @Unroll("#iterationCount: grade for #paper is #res")
    def "Grader with papers given inline"() {
        expect: "Grade an individual paper"
            that grader.grade(paper), closeTo(res, 0.01D)

        where: "With the following papers"
            paper | res
            ['a', 'b', 'c']      | 1.0D
            ['a', 'b', 'd']      | 0.66D
            ['a', 'c', 'b']      | 0.33D
            ['x', 'y', 'z']      | 0.0D
            ['c', 'a', 'b']      | 0.0D
            ['a', 'b']           | -1.0D
            ['a', 'b', 'c', 'd'] | -1.0D
            []                   | -1.0D
            null                 | -1.0D
    }
}
