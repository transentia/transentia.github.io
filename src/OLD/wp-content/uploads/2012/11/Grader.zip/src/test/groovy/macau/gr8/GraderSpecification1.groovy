package macau.gr8;

import spock.lang.Specification
import static spock.util.matcher.HamcrestMatchers.closeTo

// requires: hamcrest-core-1.2.jar
//           spock-core-0.5-groovy-1.7
//           groovy-1.7.10

//@Grapes([
//  @Grab('org.spockframework:spock-core:0.5-groovy-1.7'),
//  @Grab(
//  group='org.hamcrest',
//  module='hamcrest-core',
//  version='1.2'
//)
//])
public class GraderSpecification1 extends Specification {
    def grader

    def "The perfect paper"() {
        when: "A perfect answer is presented"
          def result = grader.grade(['a','b','c'])

        then: "The grade should be 100%"
          result == 1.0
    }

    def "The worst paper"() {
        when: "No answers are given"
          def result = grader.grade([])

        then: "An error should be indicated"
          result == -1.0
    }

    def "A poor paper"() {
        when: "The fairly poor paper is presented"
          def result = grader.grade(['a','c','b'])

        then: "The grade should be 33%"
          result closeTo(0.33D, 0.01D)
    }

    def setup()  {
        grader = new Grader(expectedAnswers: ['a','b','c'])
    }

    def cleanup() {
        grader = null
    }
}
