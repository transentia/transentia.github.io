package macau.gr8;

// requires: cglib-nodep-2.1.jar
//           hamcrest-core-1.2.jar
//           spock-core-0.5-groovy-1.7
//           groovy-1.7.10


import spock.lang.Specification
import spock.lang.AutoCleanup

class GraderSpecification2 extends Specification {
    @AutoCleanup(quiet = true)
    def grader = new Grader(expectedAnswers: ['a','b','c'])

    def "Given a non-existent file"() {
        setup: "Establish the grader with a real GraderFileReader"
          grader.graderFileReader = new GraderFileReader()
        
        when: "Read a paper's answers from a non-existant file"
          grader.grade('THIS-FILE-DOES-NOT-EXIST')

        then: "Ensure there is an exception thrown"
          thrown(Exception)
    }

    def "Given a real file"() {
        setup: "Establish the grader with a real GraderFileReader"
          grader.graderFileReader = new GraderFileReader()

        when: "Read a paper's answers from a given file"
          def res = grader.grade('rsrc/100pct.txt')

        then: "Ensure expected behaviour"
          res == 1.0D
    }

    def "Given a mock file"() {
        setup: "Establish the grader with a mocked GraderFileReader"
          def graderFileReader = Mock(GraderFileReader)
          grader.graderFileReader = graderFileReader
          1 * graderFileReader.readGradesListFromFile(_) >> ['a','b','c']
          0 * _._

        when: "Read a paper's answers from a given file"
         def res  = grader.grade('100pct.txt')
        
        then: "Ensure expected behaviour"
          res == 1.0D
    }
}
