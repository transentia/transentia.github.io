To run this you will need:

java 1.6; I use jdk1.6.0_30
gradle 1.0; I use gradle-1.0-milestone-6

To execute on Win7:

C:\DEVELOPMENT\MockingBird>cls && gradle test
:compileJava UP-TO-DATE
:compileGroovy UP-TO-DATE
:processResources UP-TO-DATE
:classes UP-TO-DATE
:compileTestJava UP-TO-DATE
:compileTestGroovy
:processTestResources UP-TO-DATE
:testClasses
:test

BUILD SUCCESSFUL

Total time: 22.246 secs
C:\DEVELOPMENT\MockingBird>

NB: you can speed things up a fair bit on all but the first run by passing the -a parameter to gradle, thus:

C:\DEVELOPMENT\MockingBird>cls && gradle -a test

The "-a" parameter sets gradle's "Do not rebuild project dependencies." mode and so avoids any associated repository lookup overheads.

HTML reports are created in:

build\reports\tests\index.html

BOB
8:58 AM 19/12/2011