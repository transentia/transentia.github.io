import geb.*
import geb.spock.*

import static org.apache.commons.lang.StringUtils.strip
import spock.lang.*
import groovy.json.*
import org.junit.Rule
import betamax.Betamax
import betamax.Recorder

class BetamaxMockingBirdSpecification extends GebSpec {
  @Rule Recorder recorder = new Recorder()

  @Betamax(tape="ToKillAMockingBird.tape")
  def "scrape 'To Kill a MockingBird' quotes"() {
    setup:
      browser.driver.setProxy("localhost", recorder.proxyPort)
    when:
      to FinestQuotesPage
    then:
      at FinestQuotesPage
    and:
      produceJSON()
  }

  void produceJSON() {
    new StringWriter().with { sw ->
      new StreamingJsonBuilder(sw).quotes() {
        generated new Date()
        title heading
        size quotes.size()
        quotes quotes.collect([]) { q ->
          [
          quote: strip(q.quote, "   ~"),
          attribution: q.attribution
          ]
        }
      }
    println JsonOutput.prettyPrint(sw.toString())
    }
  }
}

