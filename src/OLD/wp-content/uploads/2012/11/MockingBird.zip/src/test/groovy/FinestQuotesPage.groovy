import geb.*
 
class FinestQuotesPage extends Page {
  static url =
    "http://www.finestquotes.com/movie_quotes" +
      "/movie/To%20Kill%20a%20Mockingbird/page/0.htm"
  static at = { title.startsWith('Quotes') }
  static content = {
    quotes {
      $("div#container1 > div", id: "containerin").collect {
        module Quote, it
      }
    }
    heading { $("div#middletitles strong").text() }
  }
}

