import geb.*
 
class Quote extends Module {
  static content = {
    quote {
      $("span.indquote_link").text()
    }
    attribution {
      $("div", id: "authortab").text()
    }
  }
}


