// https://raw.github.com/jvmisc22/mongo-jndi/master/src/main/java/com/mongodb/MongoCitiesDatabase.java
package mongodb;

import com.mongodb.*;
import rest.InvalidDataException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

public class MongoCitiesDatabase {

    public static Set<String> findAllCities() throws InvalidDataException {
        DBObject fields = new BasicDBObject();
        fields.put("origin", 1);
        fields.put("_id", 0);
        DBObject project = new BasicDBObject("$project", fields);

        final Set<String> ss = new HashSet<>();
        MongoClient mc = MongoSingleton.INSTANCE.getMongoClient();
        DB db = null;
        try {
            db = mc.getDB("cities");

            // http://docs.mongodb.org/ecosystem/drivers/java-concurrency/
            db.requestStart();
            db.requestEnsureConnection();

            DBCollection cities = db.getCollection("cities");

            AggregationOutput output = cities.aggregate(project);
            if (!output.getCommandResult().ok())
                throw new InvalidDataException("No Cities found.");

            for (DBObject r : output.results()) {
                String s = (String) r.get("origin");
                ss.add(s);
            }
        } finally {
            try {
                db.requestDone();
            } catch (NullPointerException e) {
                /* SQUELCH!*/
            }
        }
        return ss;
    }

    public static Set<String> findDestinationsBySource(String source) throws InvalidDataException {
        DBObject match = new BasicDBObject("$match", new BasicDBObject("origin", source));

        DBObject fields = new BasicDBObject();
        fields.put("destination.city", 1);
        fields.put("_id", 0);
        DBObject project = new BasicDBObject("$project", fields);

        final Set<String> destinations = new HashSet<>();

        MongoClient mc = MongoSingleton.INSTANCE.getMongoClient();
        DB db = null;
        try {
            db = mc.getDB("cities");

            // http://docs.mongodb.org/ecosystem/drivers/java-concurrency/
            db.requestStart();
            db.requestEnsureConnection();

            DBCollection cities = db.getCollection("cities");

            AggregationOutput output = cities.aggregate(match, project);
            if (!output.getCommandResult().ok())
                throw new InvalidDataException(String.format("/{source: %1$s}/destinations. Source not found.", source));

            for (DBObject r : output.results()) {
                BasicDBList destination = (BasicDBList) r.get("destination");
                for (Object d : destination) {
                    BasicDBObject o = (BasicDBObject) d;
                    String c = (String) o.get("city");
                    destinations.add(c);
                }
            }
        } finally {
            try {
                db.requestDone();
            } catch (NullPointerException e) {
                /* SQUELCH!*/
            }
        }
        return destinations;
    }

    // http://www.mkyong.com/mongodb/java-mongodb-query-document/
    public static BigDecimal findCostBySourceAndDestination(String source, String dest) throws InvalidDataException {
        DBObject unwind = new BasicDBObject("$unwind", "$destination");

        BasicDBObject andQuery = new BasicDBObject();
        List<BasicDBObject> obj = new ArrayList<>();
        obj.add(new BasicDBObject("origin", source));
        obj.add(new BasicDBObject("destination.city", dest));
        andQuery.put("$and", obj);

        DBObject match = new BasicDBObject("$match", andQuery);

        DBObject fields = new BasicDBObject();
        fields.put("destination.cost", 1);
        fields.put("_id", 0);
        DBObject project = new BasicDBObject("$project", fields);

        MongoClient mc = MongoSingleton.INSTANCE.getMongoClient();
        DB db = null;
        try {
            db = mc.getDB("cities");

            // http://docs.mongodb.org/ecosystem/drivers/java-concurrency/
            db.requestStart();
            db.requestEnsureConnection();

            DBCollection cities = db.getCollection("cities");

            AggregationOutput output = cities.aggregate(unwind, match, project);
            if (!output.getCommandResult().ok())
                throw new InvalidDataException(String.format("{source: %1$s} or {destination: %2$s} not found.", source, dest));

            for (DBObject r : output.results()) {
                BasicDBObject destination = (BasicDBObject) r.get("destination");
                return new BigDecimal((Double) destination.get("cost")).setScale(2, RoundingMode.CEILING);
            }
        } finally {
            try {
                db.requestDone();
            } catch (NullPointerException e) {
                /* SQUELCH!*/
            }
        }

        // should not happen!
        throw new InvalidDataException(String.format("Given ({source: %1$s}, {destination: %2$s}); no data.", source, dest));
    }

    // Joshua Bloch's Java 1.5+ Singleton Pattern
    // http://books.google.com.au/books?id=ka2VUBqHiWkC&pg=PA17&lpg=PA17&dq=singleton+bloch&source=bl&ots=yYKmLgv1R-&sig=fRzDz11i4NnvspHOlooCHimjh2g&hl=en&sa=X&ei=xvOwUsLVAuSOiAeVyYHoAQ&ved=0CDgQ6AEwAg#v=onepage&q=singleton%20bloch&f=false
    private enum MongoSingleton {
        INSTANCE;
        private static final Logger log = Logger.getLogger(MongoSingleton.class.getName());
        private MongoClient mongoClient = null;

        MongoClient getMongoClient() {
            MongoClientOptions options = MongoClientOptions.builder()
                    .connectionsPerHost(25)
                    .build();

            if (mongoClient == null)
                try {
                    ServerAddress serverAddress = new ServerAddress("localhost", 30000);
                    mongoClient = new MongoClient(serverAddress, options);
                } catch (UnknownHostException uhe) {
                    String msg = "getMongoClient(); configuration issue. UnknownHostException: " + uhe.getMessage();
                    log.severe(msg);
                    throw new RuntimeException(msg, uhe);
                }

            return mongoClient;
        }
    }
}
