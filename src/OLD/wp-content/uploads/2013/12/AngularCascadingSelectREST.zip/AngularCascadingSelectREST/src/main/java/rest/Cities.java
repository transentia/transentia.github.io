package rest;

import mongodb.MongoCitiesDatabase;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

@Path("/cities")
@Produces(MediaType.APPLICATION_JSON)
public class Cities {

    private static final Logger log = Logger.getLogger(Cities.class.getName());

    @GET
    public Map<String, Set<String>> getDefault() {
        log.info("getDefault()");

        return sources();
    }

    @GET
    @Path("/sources")
    public Map<String, Set<String>> sources() {
        log.info("sources()");

        return new HashMap<String, Set<String>>() {{
            put("sources", MongoCitiesDatabase.findAllCities());
        }};
    }

    @GET
    @Path("/{source}/destinations")
    public Map<String, Set<String>> destination(@PathParam("source") final String source) {
        log.info(String.format("/{source: %1$s}/destinations", source));

        return new HashMap<String, Set<String>>() {{
            put("destinations", MongoCitiesDatabase.findDestinationsBySource(source));
        }};
    }
}
