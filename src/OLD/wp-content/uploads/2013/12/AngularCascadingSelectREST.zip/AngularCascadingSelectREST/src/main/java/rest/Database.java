package rest;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

public class Database {

    public static Map<String, Map<String, BigDecimal>> initDatabase() {

        final Map<String, BigDecimal> brisbane = new HashMap<String, BigDecimal>() {{
            put("Brisbane", new BigDecimal(0.0D).setScale(2, RoundingMode.CEILING));
            put("Darwin", new BigDecimal(44.44D).setScale(2, RoundingMode.CEILING));
            put("Canberra", new BigDecimal(22.22D).setScale(2, RoundingMode.CEILING));
            put("Hobart", new BigDecimal(88.88D).setScale(2, RoundingMode.CEILING));
            put("Sydney", new BigDecimal(111.11D).setScale(2, RoundingMode.CEILING));
        }};
        final Map<String, BigDecimal> darwin = new HashMap<String, BigDecimal>() {{
            put("Brisbane", new BigDecimal(44.44D).setScale(2, RoundingMode.CEILING));
            put("Darwin", new BigDecimal(0.0D).setScale(2, RoundingMode.CEILING));
            put("Canberra", new BigDecimal(33.33D).setScale(2, RoundingMode.CEILING));
            put("Hobart", new BigDecimal(99.99D).setScale(2, RoundingMode.CEILING));
        }};
        final Map<String, BigDecimal> canberra = new HashMap<String, BigDecimal>() {{
            put("Brisbane", new BigDecimal(22.22D).setScale(2, RoundingMode.CEILING));
            put("Darwin", new BigDecimal(33.33D).setScale(2, RoundingMode.CEILING));
            put("Canberra", new BigDecimal(0.0D).setScale(2, RoundingMode.CEILING));
            put("Hobart", new BigDecimal(77.77D).setScale(2, RoundingMode.CEILING));
        }};
        final Map<String, BigDecimal> hobart = new HashMap<String, BigDecimal>() {{
            put("Brisbane", new BigDecimal(88.88D).setScale(2, RoundingMode.CEILING));
            put("Darwin", new BigDecimal(99.99).setScale(2, RoundingMode.CEILING));
            put("Canberra", new BigDecimal(77.77D).setScale(2, RoundingMode.CEILING));
            put("Hobart", new BigDecimal(0.0D).setScale(2, RoundingMode.CEILING));
        }};

        return new HashMap<String, Map<String, BigDecimal>>() {{
            put("Brisbane", brisbane);
            put("Darwin", darwin);
            put("Canberra", canberra);
            put("Hobart", hobart);
        }};
    }

}
