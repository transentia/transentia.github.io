package rest;

public class InvalidDataException extends RuntimeException {

  @SuppressWarnings("unused")
  public InvalidDataException() {
      this("An InvalidDataException Occurred.");
  }

  public InvalidDataException(String message) {
      super(message);
  }
}
