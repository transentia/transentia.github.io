package rest;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

@WebFilter(filterName = "RestFilter",
        urlPatterns = {"/rest/*"})
public class RestFilter implements Filter {

    // JSON Vulnerability protection in angular
    // see: http://docs.angularjs.org/api/ng.$http
    private static final String AngularJSJSONVulnerabilityProtectionString = ")]}',\n";

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {

        HttpServletResponse response = (HttpServletResponse) res;

        StringResponseWrapper responseWrapper = new StringResponseWrapper(response);

        chain.doFilter(req, responseWrapper);

        String content = responseWrapper.toString();

        // turn on AngularJS' JSON vulnerability protection feature
        // ignore mapped exceptions and anything else not 'Kosher'
        if (MediaType.APPLICATION_JSON.equals(responseWrapper.getHeader("Content-Type")))
            content = String.format("%1$s%2$s", AngularJSJSONVulnerabilityProtectionString, content);

        byte[] bytes = content.getBytes();

        response.setContentLength(bytes.length);
        response.getOutputStream().write(bytes);
    }

    @Override
    public void init(FilterConfig config) throws ServletException {
    }

    @Override
    public void destroy() {
    }

    //    http://stackoverflow.com/questions/1302072/how-can-i-get-the-http-status-code-out-of-a-servletresponse-in-a-servletfilter/1302165#1302165
    private class StringResponseWrapper
            extends HttpServletResponseWrapper {

        private StringWriter writer;

        public StringResponseWrapper(HttpServletResponse response) {
            super(response);
            writer = new StringWriter();
        }

        @Override
        public PrintWriter getWriter() {
            return new PrintWriter(writer);
        }

        @Override
        public ServletOutputStream getOutputStream() {
            return new StringOutputStream(writer);
        }

        @Override
        public String toString() {
            return writer.toString();
        }
    }

    private class StringOutputStream extends ServletOutputStream {
        private StringWriter stringWriter;

        public StringOutputStream(StringWriter stringWriter) {
            this.stringWriter = stringWriter;
        }

        public void write(int c) {
            stringWriter.write(c);
        }

        public boolean isReady() {
            return true;
        }

        public void setWriteListener(WriteListener writeListener) {
        }
    }
}



