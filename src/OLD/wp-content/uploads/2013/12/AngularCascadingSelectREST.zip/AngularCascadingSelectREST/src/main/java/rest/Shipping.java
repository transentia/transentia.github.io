package rest;

import mongodb.MongoCitiesDatabase;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * An "Algorithmic REST Resource" that determines the cost of shipping items around the capital cities of Australia.
 *
 * @servicetag Cities
 *
 * @author Bob
 */

@Path("/shipping")
public class Shipping {

    private static final Logger log = Logger.getLogger(Shipping.class.getName());

    /**
     * Determines the cost of shipping items around the capital cities of Australia.
     *
     * @param  origin Where to ship from
     * @param destination Where to ship to
     * @param quantity how many to ship
     * @return The cost of shipping items
     * @throws InvalidDataException leading to a 404 return status.
     * @statuscode 404 If any of the origin or destination parameters can't be found.
     */
    @Produces(MediaType.APPLICATION_JSON)
    @GET
    @Path("/calculate")
    public Map<String, Map<String, BigDecimal>> calculate(@QueryParam("origin") String origin, @QueryParam("destination") String destination,
                                                          @DefaultValue("1") @QueryParam("quantity") Integer quantity) {
        log.info(String.format("calculate():: Origin: %1$s; Destination: %2$s; Quantity: %3$d", origin, destination, quantity));

        BigDecimal costPer = MongoCitiesDatabase.findCostBySourceAndDestination(origin, destination);
        final BigDecimal res = costPer.multiply(BigDecimal.valueOf(quantity).setScale(2, RoundingMode.CEILING));

        final Map<String, BigDecimal> resMap = new HashMap<String, BigDecimal>() {{
            put("result", res);
        }};

        return new HashMap<String, Map<String, BigDecimal>>() {{
            put("calculate", resMap);
        }};
    }
}

