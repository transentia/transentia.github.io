'use strict';


// Declare app level module which depends on filters, and services
angular.module('cascadeSelects', [
  'ngRoute',
  'cascadeSelects.filters',
  'cascadeSelects.services',
  'cascadeSelects.directives',
  'cascadeSelects.controllers'
]).
config(['$routeProvider', '$httpProvider', function($routeProvider, $httpProvider) {
  $routeProvider.when('/', {templateUrl: 'partials/cascadeSelectsPartial.html', controller: 'CascadeSelectsController'});
  $routeProvider.otherwise({redirectTo: '/'});
//
//        function stripPfx (data, headersGetter) {
//            console.log("stringPFX***");
//            console.dir(data);
//            console.dir(headersGetter());
//
//            if(data === undefined) return undefined;
//
//            return angular.fromJson(data.substring("for(;;);".length))
//        }
//
//        $httpProvider.defaults.transformRequest.push(stripPfx);
}]);
