'use strict';

/* Controllers */

angular.module('cascadeSelects.controllers', []).
    controller('CascadeSelectsController', ['$scope', 'Cities', function($scope, Cities) {

        $scope.error = undefined;

        // TODO: something better needed here
        function error(r) {
            $scope.error = "Error: " + r.status + ". Message: " + r.data;
        }

        // Instantiate an object to store your scope data in (Best Practices)
        $scope.cities = {
            sources: null,
            chosen: null
        };
        $scope.destinations = {
            destinations: null,
            chosen: null
        };
        $scope.shipping = {
            calculateShipping: function() {
                Cities.calculate.get({origin: $scope.cities.chosen, destination: $scope.destinations.chosen,
                                      quantity: $scope.shipping.quantity}, function(response) {
                    $scope.shipping.calculateShippingResponse = response.calculate.result;
                }, function(httpResponse) {
                    console.log(error(httpResponse));
                })
            },
            calculateShippingResponse: undefined,
            quantity: 1
        };

        Cities.cities.query(function(response) {
            $scope.cities.sources = response.sources;
            $scope.cities.chosen = $scope.cities.sources[0]
        }, function(httpResponse) {
            console.log(error(httpResponse));
        });

        $scope.$watch("[shipping.quantity, destinations.chosen, cities.chosen]", function(newValue, oldValue, scope) {
            $scope.shipping.calculateShippingResponse = undefined;
            $scope.error = undefined;
        }, true);

        $scope.$watch("cities.chosen", function(newValue, oldValue, scope) {
            if (newValue === null)
                return;
            Cities.destinations.query({source: newValue}, function(response) {
                    $scope.destinations.destinations = response.destinations;
                    $scope.destinations.chosen = $scope.destinations.destinations[0]
                }, function(httpResponse) {
                    console.log(error(httpResponse));
                }
            )
        }, true);
    }]);
