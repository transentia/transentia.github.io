'use strict';

/* Directives */


angular.module('cascadeSelects.directives', []).
  directive('appVersion', ['version', function(version) {
    return function(scope, elm, attrs) {
      elm.text(version);
    };
  }]);
