'use strict';

/* Services */

angular.module('cascadeSelects.services', ['ngResource']).
    factory("Cities", function($resource){

        var context = '/web_war';
        return {
            cities: $resource(context + '/rest/cities', {}, {
                query: {method: 'GET', params: {}, isArray: false}
            }),
            destinations: $resource(context + '/rest/cities/:source/destinations', {}, {
                query: {method: 'GET', params: {source: '@source'}, isArray: false}
            }),
            calculate: $resource(context + '/rest/shipping/calculate', {}, {
                get: {method: 'GET', params: {origin: '@origin', destination: '@destination', quantity: '@quantity'}, isArray: false}
            })
        };
    })
    .value('version', '1.0');
